package org.example.db;

import org.example.auth.Email;
import org.example.domain.Employee;
import org.example.domain.Phone;
import org.example.domain.Role;
import org.example.dto.KeyValueDTO;

import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class EmployeeDB implements PersistableObject<Employee> {

    private final List<Employee> employeeList;

    public EmployeeDB(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }
    @Override
    public boolean save(Connection connection, Employee object) {
        String sqlCmd;
        sqlCmd = "select * from Employee where employeeID = ?";
        try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
            ps.setInt(1, object.employeeID());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    sqlCmd = "update Employee set employee_Name = ?, employee_Email = ?, employee_Role = ?, employee_PhoneNumber = ? where employeeID = ?";
                }
                else {
                    sqlCmd = "insert into Employee(employeeID, employee_Name, employee_Email, employee_Role, employee_PhoneNumber) values (?, ?, ?, ?, ?)";
                }

                try (PreparedStatement ps2 = connection.prepareStatement(sqlCmd)) {
                    ps2.setInt(1, object.employeeID());
                    ps2.setString(2, object.employee_Name());
                    Email email = object.employee_Email();
                    if (email != null) {
                        ps2.setString(3, email.address());
                    } else {
                        ps2.setNull(3, java.sql.Types.VARCHAR);
                    }
                    Role role = object.employee_Role();
                    if (role != null) {
                        ps2.setString(4, role.role());
                    } else {
                        ps2.setNull(4, java.sql.Types.VARCHAR);
                    }
                    Phone phone = object.employee_PhoneNumber();
                    if (phone != null) {
                        ps2.setInt(5, phone.phoneNumber());
                    } else {
                        ps2.setNull(5, java.sql.Types.INTEGER);
                    }

                    ps2.executeUpdate();
                    connection.commit();
                    employeeList.add(object);
                    System.out.println("Employee saved successfully.");
                    return true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmployeeDB.class.getName()).log(Level.SEVERE, "Error saving Employee", ex);
            System.err.println("Failed to save employee: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(Connection connection, Employee object) {
        try {
            String sqlCmd;
            sqlCmd = "delete from Employee where employeeID = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setInt(1, object.employeeID());
                ps.executeUpdate();
                employeeList.remove(object);
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmployeeDB.class.getName()).log(Level.SEVERE, "Error deleting Employee", ex);
            return false;
        }
    }

    @Override
    public Employee getById(Connection connection, int id) {
        try {
            String sqlCmd;
            sqlCmd = "select * from Employee where employeeID = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    Employee employee = null;
                    try {
                        employee = new Employee.Builder()
                                .withId(rs.getInt("employeeID"))
                                .withName(rs.getString("employee_Name"))
                                .withEmail(new Email(rs.getString("employee_Email")))
                                .withRole(new Role(rs.getString("employee_Role")))
                                .withPhone(new Phone(rs.getInt("employee_PhoneNumber")))
                                .build();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return employee;
                }
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmployeeDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    public List<Employee> getEmployeeList() {
        return employeeList;
    }
    public List<KeyValueDTO> keyValueDTOList() {
        return employeeList.stream()
                .map(item -> new KeyValueDTO(item.toDTO().employeeID().toString(), item.toDTO().employee_Name()))
                .collect(Collectors.toList());
    }
}


