package org.example.db;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ConnectionFactory {
    private final Integer connectionPoolCount = 2;

    private Integer connectionPoolRequest = 0;
    private static ConnectionFactory cf;
    private final List<DatabaseConnection> dbConnectionList = new ArrayList<>();


    public DatabaseConnection getDatabaseConnection() throws SQLException {
        DatabaseConnection c;
        if (++connectionPoolRequest > connectionPoolCount) {
            connectionPoolRequest = 1;
        }
        if (connectionPoolRequest > dbConnectionList.size()) {
            c = new DatabaseConnection( //cria uma nova connection
                    "jdbc:oracle:thin:@upskill.dnsfor.me:1521/freepdb1",
                    "upskill13",
                    "qwerty");
            dbConnectionList.add(c);
        }
        else {
            c = dbConnectionList.get(connectionPoolRequest-1);
        }
        return c;
    }
}
