package org.example.ui;

public class ScheduleVaccinationUI extends UI {
}
