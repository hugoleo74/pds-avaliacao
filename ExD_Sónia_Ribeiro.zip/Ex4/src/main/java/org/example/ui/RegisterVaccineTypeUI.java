package org.example.ui;

import org.example.controller.VaccineTechController;
import org.example.controller.VaccineTypeController;
import org.example.dto.VaccineTechDTO;
import org.example.dto.VaccineTypeDTO;
import org.example.dto.DTO;

import static org.example.ui.utils.UITools.showKeyValueList;
import static org.example.ui.utils.Utils.readIntegerFromConsole;
import static org.example.ui.utils.Utils.readLineFromConsole;

public class RegisterVaccineTypeUI extends UI {
//    private final VaccineTypeController vaccineTypeController = new VaccineTypeController();
//    private final VaccineTechController vaccineTechController = new VaccineTechController();
//
//    public void run() {
//        System.out.println("");
//        System.out.println("CREATE VACCINE TYPE");
//        System.out.println("-----------");
//
//        /*try {
//            String code = readLineFromConsole("Vaccine Type Code: ");
//            String shortDescription = readLineFromConsole("Vaccine Type Short Description: ");
//
//            System.out.println("Vaccine Technologies");
//            List<VaccineTech> vaccineTechList = vaccineTechController.vaccineTechList();
//            for (VaccineTech vaccineTech : vaccineTechList) {
//                System.out.println(vaccineTech.id() + " - " + vaccineTech.name());
//            }
//            int key = readIntegerFromConsole("Select a vaccine technology: ");
//
//            //data
//            vaccineTypeController.createVaccineType(code, shortDescription, key);
//
//            //confirmation
//            vaccineTypeController.confirm();
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//
//         */
//
//
//        try {
//            //System asks: code, short description, vaccine technology
//            String code = readLineFromConsole("Vaccine Type Code: ");
//            String shortDescription = readLineFromConsole("Vaccine Type Short Description: ");
//            showKeyValueList("Vaccine Technologies", new VaccineTechController().keyValueDTOList());
//            int key = readIntegerFromConsole("Select a vaccine technology: ");
//
//            //DTO creation
//            VaccineTypeDTO dto = new VaccineTypeDTO.Builder()
//                    .withCode(code)
//                    .withShortDescription(shortDescription)
//                    .withVaccineTechDTO(new VaccineTechDTO.Builder()
//                            .withId(key)
//                            .build())
//                    .build();
//
//            //Registration
//            vaccineTypeController.register(dto);
//
//            //confirmation
//            vaccineTypeController.save();
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//    }
}

