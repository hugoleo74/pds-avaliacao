package org.example.ui;

import org.example.controller.BrandController;
import org.example.controller.CreateEmployeeController;
import org.example.controller.RoleController;
import org.example.controller.VaccineTypeController;
import org.example.domain.Employee;
import org.example.domain.Role;
import org.example.dto.*;
import java.util.Arrays;

import java.util.List;

import static org.example.ui.utils.UITools.showKeyValueList;
import static org.example.ui.utils.Utils.readLineFromConsole;

public class CreateEmployeeUI extends UI {
    private final CreateEmployeeController createEmployeeController = new CreateEmployeeController();
    private final RoleController roleController = new RoleController();

    private final List<RoleDTO> roles = Arrays.asList(
            new RoleDTO.Builder().withRole("Administrator").build(),
            new RoleDTO.Builder().withRole("Receptionist").build(),
            new RoleDTO.Builder().withRole("Nurse").build()
    );

    public void run(){
        System.out.println("");
        System.out.println("CREATE EMPLOYEE");
        System.out.println("-----------");

        try {
            //System asks: name, email, role, phone
            String employee_Name = readLineFromConsole("Employee's Name: ");
            String employee_Email = readLineFromConsole("Employee's E-mail: ");
            //System.out.println("Employee's roles:");
            //for (RoleDTO role : roles) {
            //    System.out.println(role.role());
            //}
            //String employee_Role = readLineFromConsole("Select a role: ");
            showKeyValueList("List of Employee Roles", new RoleController().keyValueDTOList());
            String employee_Role = readLineFromConsole("Select a role: ");
            Integer employee_PhoneNumber = Integer.valueOf(readLineFromConsole("Employee's Phone Number: "));



            //DTO
            EmployeeDTO dto = new EmployeeDTO.Builder()
                    .withName(employee_Name)
                    .withEmailDTO(new EmailDTO.Builder()
                            .withEmail(employee_Email)
                            .build())
                    //.withRole(employee_Role)
                    .withRoleDTO(new RoleDTO.Builder()
                            .withRole(employee_Role)
                            .build())
                    .withPhoneDTO(new PhoneDTO.Builder()
                            .withPhoneNumber(employee_PhoneNumber)
                            .build())
                    .build();

            //Registration
            createEmployeeController.register(dto);

            //Confirmation
            if (createEmployeeController.save()) {
                System.out.println("Employee created successfully.");
            } else {
                System.out.println("Failed to create employee.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
