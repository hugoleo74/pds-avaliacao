package org.example.ui;

public class ScheduleVaccinationOnBehalfOfUserUI extends UI {
}
