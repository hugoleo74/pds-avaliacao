package org.example.ui;

public class RegisterUserArrivalUI extends UI {
}
