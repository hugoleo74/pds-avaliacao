package org.example.ui;

import org.example.controller.VaccineTechController;
import org.example.controller.VaccineTypeController;

import static org.example.ui.utils.UITools.showKeyValueList;

public class ListVaccineTypesUI extends UI {

    private final VaccineTypeController vaccineTypeController = new VaccineTypeController();
    private final VaccineTechController vaccineTechController = new VaccineTechController();

    public void run() {
        System.out.println("");
        System.out.println("LIST VACCINE TYPES");
        System.out.println("-----------");

       /* try {
            List<VaccineType> vaccineTypeList = vaccineTypeController.vaccineTypeList();
            for (VaccineType vaccineType : vaccineTypeList) {
                String vaccineTechName = vaccineTechController.getVaccineTechName(vaccineType.vaccineTech().id());
                System.out.println(vaccineType.code() + " - " + vaccineType.shortDescription() + " - " + vaccineTechName);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        */
        showKeyValueList("", new VaccineTypeController().keyValueDTOList());
    }
}

