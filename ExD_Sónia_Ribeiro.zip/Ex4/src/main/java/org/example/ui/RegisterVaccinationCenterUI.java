package org.example.ui;

import org.example.controller.VaccinationCenterController;

import static org.example.ui.utils.Utils.readLineFromConsole;

public class RegisterVaccinationCenterUI extends UI {

    private final VaccinationCenterController vaccinationCenterController = new VaccinationCenterController();

    public void run() {
        System.out.println("");
        System.out.println("CREATE VACCINATION CENTER");
        System.out.println("-----------");

        try {
            String name = readLineFromConsole("Vaccination Center Name: ");
            String adress = readLineFromConsole("Vaccination Center Adress: ");
            int phoneNumber = Integer.parseInt(readLineFromConsole("Vaccination Center Phone Number: "));
            String emailAdress = readLineFromConsole("Vaccination Center Email Adress: ");
            int faxNumber = Integer.parseInt(readLineFromConsole("Vaccination Center Fax Number: "));
            String websiteAdress = readLineFromConsole("Vaccination Center Website Adress: ");
            int openingHours = Integer.parseInt(readLineFromConsole("Vaccination Center Opening Hours: "));
            int closingHours = Integer.parseInt(readLineFromConsole("Vaccination Center Closing Hours: "));
            int maxNumbVacPerHour = Integer.parseInt(readLineFromConsole("Vaccination Center Maximum number of vaccines per hour: "));

            vaccinationCenterController.createVaccinationCenter(name, adress, phoneNumber, emailAdress, faxNumber, websiteAdress, openingHours, closingHours, maxNumbVacPerHour);

            vaccinationCenterController.confirm();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

