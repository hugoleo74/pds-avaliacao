package org.example.ui;

import org.example.controller.CreateSnsUserController;

import static org.example.ui.utils.Utils.readLineFromConsole;

public class RegisterUserUI extends UI {

    CreateSnsUserController createSnsUserController = new CreateSnsUserController();

    @Override
    public void run() {
        System.out.println("");
        System.out.println("CREATE SNS USER");
        System.out.println("-----------");

        try {
            String name = readLineFromConsole("SNS User Name: ");
            String birthDate = readLineFromConsole("SNS User birth date: ");
            String sex = readLineFromConsole("SNS User Sex: ");
            String postAddress = readLineFromConsole("SNS User post adress: ");
            int phoneNumber = Integer.parseInt(readLineFromConsole("SNS User phone number: "));
            String emailAddress = readLineFromConsole("SNS User email address: ");
            int citizenCardNumber = Integer.parseInt(readLineFromConsole("SNS User citizen card number: "));
            int snsUserNumber = Integer.parseInt(readLineFromConsole("SNS User number: "));

            createSnsUserController.createSnsUser(name, birthDate, sex, postAddress, phoneNumber, emailAddress, citizenCardNumber, snsUserNumber);

            createSnsUserController.confirm();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}

