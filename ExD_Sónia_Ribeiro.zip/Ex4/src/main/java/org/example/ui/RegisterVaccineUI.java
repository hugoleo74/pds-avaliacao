package org.example.ui;

import org.example.controller.BrandController;
import org.example.controller.VaccineController;
import org.example.controller.VaccineTypeController;
import org.example.dto.BrandDTO;
import org.example.dto.VaccineDTO;
import org.example.dto.VaccineTypeDTO;

import static org.example.ui.utils.UITools.showKeyValueList;
import static org.example.ui.utils.Utils.readLineFromConsole;

public class RegisterVaccineUI extends UI {

    private final VaccineController vaccineController = new VaccineController();
    private final VaccineTypeController vaccineTypeController = new VaccineTypeController();
    private final BrandController brandController = new BrandController();

    public void run() {
        System.out.println("");
        System.out.println("CREATE VACCINE");
        System.out.println("-----------");

        /*try {
            List<VaccineType> vaccineTypeList = vaccineTypeController.vaccineTypeList();
            System.out.println("Vaccine Types");
            for (VaccineType vaccineType : vaccineTypeList) {
                System.out.println(vaccineType.code() + " - " + vaccineType.shortDescription());
            }
            String vaccineTypeCode = readLineFromConsole("Select a vaccine type: ");

            List<Brand> brandList = brandController.brandList();
            System.out.println("Brands");
            for (Brand brand : brandList) {
                System.out.println(brand.name());
            }
            String brandName = readLineFromConsole("Select a brand: ");

            String vaccineName = readLineFromConsole("Vaccine Name: ");

            //Set data
            vaccineController.createVaccine(vaccineTypeCode, brandName, vaccineName);

            //Confirm
            vaccineController.confirm();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

         */

        try {
            //System asks: vaccine type, brand, vaccine name
            showKeyValueList("Vaccine Types", new VaccineTypeController().keyValueDTOList());
            String vaccineTypeCode = readLineFromConsole("Select a vaccine type: ");

            showKeyValueList("Brands", new BrandController().keyValueDTOList());
            String brandName = readLineFromConsole("Select a brand: ");

            String vaccineName = readLineFromConsole("Vaccine Name: ");

            //DTO
            VaccineDTO dto = new VaccineDTO.Builder()
                    .withName(vaccineName)
                    .withVaccineTypeDTO(new VaccineTypeDTO.Builder()
                            .withCode(vaccineTypeCode)
                            .build())
                    .withBrandDTO(new BrandDTO.Builder()
                            .withName(brandName)
                            .build())
                    .build();

            //Registration
            vaccineController.register(dto);

            //Confirmation
            vaccineController.save();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

