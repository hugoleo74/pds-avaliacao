package org.example.ui.menu;

public interface Drawable {
    void draw(Menu menu);
}
