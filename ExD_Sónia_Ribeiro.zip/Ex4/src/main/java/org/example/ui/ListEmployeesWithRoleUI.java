package org.example.ui;

public class ListEmployeesWithRoleUI extends UI {
}
