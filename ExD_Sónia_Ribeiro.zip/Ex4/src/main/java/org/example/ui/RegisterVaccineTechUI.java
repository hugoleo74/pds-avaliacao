package org.example.ui;

import org.example.controller.VaccineTechController;
import org.example.dto.VaccineTechDTO;

import static org.example.ui.utils.Utils.readLineFromConsole;

public class RegisterVaccineTechUI extends UI {
    private final VaccineTechController vaccineTechController = new VaccineTechController();

    public void run() {
        System.out.println("");
        System.out.println("CREATE VACCINE TECHNOLOGY");
        System.out.println("-----------");

        try {
            //System asks: name, description
            String name = readLineFromConsole("Vaccine Technology Name: ");
            String description = readLineFromConsole("Vaccine Technology Description: ");

            //DTO creation
            VaccineTechDTO dto = new VaccineTechDTO.Builder()
                    .withName(name) //so os atributos que queremos
                    .withDescription(description)
                    .build();//chamar o metodo build

            //Registration
            vaccineTechController.register(dto);

            //Confirmation
            vaccineTechController.save();


            /*//Set data
            vaccineTechController.createVaccineTech(name, description);

            //Confirm
            vaccineTechController.confirm();
             */
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

