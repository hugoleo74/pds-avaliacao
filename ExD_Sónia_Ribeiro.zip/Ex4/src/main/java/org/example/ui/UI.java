package org.example.ui;

import java.util.Scanner;

public class UI implements Runnable{
    protected Scanner input = new Scanner(System.in);

    public void run() { };
}
