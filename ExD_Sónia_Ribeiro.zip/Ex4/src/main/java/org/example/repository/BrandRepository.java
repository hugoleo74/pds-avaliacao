package org.example.repository;

import org.example.domain.Brand;
import org.example.dto.BrandDTO;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;

import java.util.ArrayList;
import java.util.List;

public class BrandRepository implements PersistableRepo {

    public BrandRepository() {}

    private List<Brand> brandList = new ArrayList<Brand>();
    /*
        public int nextId() {
            int maxId = 0;
            for (VaccineTech vaccineTech : vaccineTechList) {
                if (vaccineTech.id() > maxId) {
                    maxId = vaccineTech.id();
                };
            }
            return maxId+1;
        }



        public VaccineTech getById(int id) {
            for (VaccineTech vaccineTech : vaccineTechList) {
                if (vaccineTech.id() == id) {
                    return vaccineTech;
                };
            }
            return null;
        }
    */
    private Boolean validateSave(Object object) {
        return true;
    }

    private Boolean validateDelete(Object object) {
        return true;
    }

    /*public Brand createBrand(String name) {
        return new Brand(name);
    }

     */
    public Brand createBrand(DTO dto) {
        BrandDTO brandDTO = (BrandDTO) dto;
        return new Brand(brandDTO.name());
    }

    @Override
    public boolean save(Object object) {
        if (validateSave(object)) {
            brandList.add((Brand) object);
            return true;
        }
        return false;
    }

    @Override
    public boolean delete(Object object) {
        if (validateDelete(object)) {
            brandList.remove(object);
            return true;
        }
        return false;
    }

    public List<Brand> brandList() {
        return brandList;
    }

    public List<KeyValueDTO> keyValueDTOList() {
        List<KeyValueDTO> dtoList = new ArrayList<>();
        for (Brand item : brandList()) {
            BrandDTO dto = item.toDTO();
            dtoList.add(new KeyValueDTO(dto.name(), ""));
        }
        return dtoList;
    }
    public Brand getByName(String name) {
        for (Brand brand : brandList) {
            if (brand.name().equals(name)) {
                return brand;
            }
        }
        return null;
    }
}
