package org.example.repository;

import org.example.domain.Role;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;
import org.example.dto.RoleDTO;

import java.util.ArrayList;
import java.util.List;

public class RoleRepository implements PersistableRepo {

    public RoleRepository(){}

    private List<Role> rolesList = new ArrayList<Role>();
    public static final String ROLE_ADMIN = "ADMINISTRATOR";
    public static final String ROLE_NURSE = "NURSE";
    //public static final String ROLE_SNSUSER = "SNSUSER";
    public static final String ROLE_RECEPTIONIST = "RECEPTIONIST";


   public boolean add(Role role) {
        try {
            rolesList.add(role);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Role roleByName(String name) {
        for (Role role : rolesList) {
            if (role.role() == name) {
                return role;
            };
        }
        return null;
    }



   private Boolean validateSave(Object object) {
       return true;
   }

    private Boolean validateDelete(Object object) {
        return true;
    }

    public Role createRole(DTO dto) {
        RoleDTO roleDTO = (RoleDTO) dto;
        return new Role(roleDTO.role());
    }


    @Override
    public boolean save(Object object) {
        if (validateSave(object)) {
            rolesList.add((Role) object);
            return true;
        }
        return false;
    }

    @Override
    public boolean delete(Object object) {
        if (validateDelete(object)) {
            rolesList.remove(object);
            return true;
        }
        return false;
    }
    public List<Role> rolesList() {
        return rolesList;
    }

    public List<KeyValueDTO> keyValueDTOList() {
        List<KeyValueDTO> dtoList = new ArrayList<>();
        for (Role item : rolesList()) {
            RoleDTO dto = item.toDTO();
            dtoList.add(new KeyValueDTO(dto.role(), ""));
        }
        return dtoList;
    }
    public Role getByName(String name) {
        for (Role role : rolesList) {
            if (role.role().equals(name)) {
                return role;
            }
        }
        return null;
    }
}
