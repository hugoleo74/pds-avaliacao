package org.example.repository;

import org.example.domain.VaccinationCenter;

public class VaccinationCenterRepository implements PersistableRepo {
    public VaccinationCenterRepository() {}

    public VaccinationCenter createVaccinationCenter(String name, String adress, int phoneNumber, String emailAdress, int faxNumber, String websiteAdress, int openingHours, int closingHours, int maxNumbVacPerHour) {
        return new VaccinationCenter(name, adress, phoneNumber, emailAdress, faxNumber, websiteAdress, openingHours, closingHours, maxNumbVacPerHour);
    }

    @Override
    public boolean save(Object object) {
        return false;
    }

    @Override
    public boolean delete(Object object) {
        return false;
    }
}
