package org.example.repository;

import org.example.auth.Email;
import org.example.db.ConnectionFactory;
import org.example.db.DatabaseConnection;
import org.example.db.EmployeeDB;
import org.example.domain.Address;
import org.example.domain.Employee;
import org.example.domain.Role;
import org.example.domain.Phone;
import org.example.dto.DTO;
import org.example.dto.EmployeeDTO;
import org.example.dto.KeyValueDTO;
import org.example.session.Context;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeRepository implements PersistableRepo {

    private final EmployeeDB employeeDB;

    public EmployeeRepository(List<Employee> employeeList) {
        this.employeeDB = new EmployeeDB(employeeList);
    }

    public int nextId() {
        int maxId = 0;
        for (Employee employee : employeeDB.getEmployeeList()) {
            if (employee.employeeID() > maxId) {
                maxId = employee.employeeID();
            };
        }
        return maxId+1;
    }

    public Employee getById(int id) {
        for (Employee employee : employeeDB.getEmployeeList()) {
            if (employee.employeeID() == id) {
                return employee;
            };
        }
        return null;
    }

    private Boolean validateSave(Employee employee) {
        return true;
    }

    private Boolean validateDelete(Employee employee) {
        return true;
    }

    public Employee createEmployee(DTO dto) throws Exception {
        EmployeeDTO employeeDTO = (EmployeeDTO) dto;
        RoleRepository roleRepository = Repositories.getInstance().roleRepository();
        return new Employee.Builder()
                .withId(nextId())
                .withName(employeeDTO.employee_Name())
                .withEmail(new Email(employeeDTO.employee_EmailDTO().address()))
                .withRole(new Role(employeeDTO.employee_RoleDTO().role()))
                .withPhone(new Phone(employeeDTO.employee_PhoneNumberDTO().phoneNumber()))
                .build();
    }
    @Override
    public boolean save(Object object) {
        Connection conn = null;
        try {
            conn = Context.getInstance().getDBConnection();
            conn.setAutoCommit(false);


            boolean result = employeeDB.save(conn, (Employee) object);

            if (result) {
                conn.commit();
                return true;
            } else {
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(Object object) {
        Connection conn = null;
        try {
            conn = Context.getInstance().getDBConnection();
            conn.setAutoCommit(false);

            boolean result = employeeDB.delete(conn, (Employee) object);

            if (result) {
                conn.commit();
                return true;
            } else {
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public List<Employee> getEmployeeList() {
        return employeeDB.getEmployeeList();
    }

    public List<KeyValueDTO> keyValueDTOList() {
        return employeeDB.keyValueDTOList();
    }
}
