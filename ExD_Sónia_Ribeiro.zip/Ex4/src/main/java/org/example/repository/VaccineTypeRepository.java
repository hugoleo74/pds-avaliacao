package org.example.repository;

import org.example.domain.VaccineType;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;
import org.example.dto.VaccineTypeDTO;

import java.util.ArrayList;
import java.util.List;

public class VaccineTypeRepository implements PersistableRepo {

    private List<VaccineType> vaccineTypeList = new ArrayList<VaccineType>();

    /*public VaccineType createVaccineType(String code, String shortDescription, VaccineTech vaccineTech) {
        return new VaccineType(code, shortDescription, vaccineTech);
    }

     */
    public VaccineType createVaccineType(DTO dto) {
        VaccineTypeDTO vaccineTypeDTO = (VaccineTypeDTO) dto;
        VaccineTechRepository vaccineTechRepository = Repositories.getInstance().vaccineTechRepository();
        return new VaccineType(vaccineTypeDTO.code(), vaccineTypeDTO.shortDescription(), vaccineTechRepository.getById(vaccineTypeDTO.vaccineTechDTO().id()));
    }

    @Override
    public boolean save(Object object) {
        vaccineTypeList.add((VaccineType) object);
        return true;
    }

    @Override
    public boolean delete(Object object) {
        vaccineTypeList.remove(object);
        return true;
    }

    public List<VaccineType> vaccineTypeList() {
        return vaccineTypeList;
    }

    public VaccineType getByCode(String code) {
        for (VaccineType vaccineType : vaccineTypeList) {
            if (vaccineType.code().equals(code)) {
                return vaccineType;
            }
        }
        return null;
    }
    public List<KeyValueDTO> keyValueDTOList() {
        List<KeyValueDTO> dtoList = new ArrayList<>();
        for (VaccineType item : vaccineTypeList()) {
            VaccineTypeDTO dto = item.toDTO();
            dtoList.add(new KeyValueDTO(dto.code(), dto.shortDescription() + " - Technology: " + dto.vaccineTechDTO().id()));
        }
        return dtoList;
    }
}

