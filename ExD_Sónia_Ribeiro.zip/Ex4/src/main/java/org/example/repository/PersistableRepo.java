package org.example.repository;

import java.sql.SQLException;

public interface PersistableRepo {
    boolean save(Object object) throws SQLException;
    boolean delete(Object object) throws SQLException;
}
