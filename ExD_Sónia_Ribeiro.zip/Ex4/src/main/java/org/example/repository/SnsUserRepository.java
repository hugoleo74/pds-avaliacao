package org.example.repository;

import org.example.domain.SnsUser;

public class SnsUserRepository implements PersistableRepo {

    public SnsUserRepository(){}

    public SnsUser createSnsUser(String name, String birthDate, String sex, String postAddress, int phoneNumber, String emailAddress, int citizenCardNumber, int snsUserNumber){
        return new SnsUser(name, birthDate, sex, postAddress, phoneNumber, emailAddress, citizenCardNumber, snsUserNumber);
    }
    @Override
    public boolean save(Object object) {
        return false;
    }

    @Override
    public boolean delete(Object object) {
        return false;
    }
}
