package org.example.session;

import org.example.auth.User;

public class Session {
    User user;


    public Session(User user) {
        this.user = user;
    }

    public User user() {
        return this.user;
    }


}
