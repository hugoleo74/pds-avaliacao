package org.example.session;

import org.example.auth.User;
import org.example.db.ConnectionFactory;
import org.example.db.DatabaseConnection;
import org.example.ui.menu.Drawable;
import org.example.ui.menu.Menu;

import java.sql.Connection;
import java.sql.SQLException;

public class Context {

    public static Context getInstance() {
        return SingletonHolder.INSTANCE;
    }

    private static class SingletonHolder {
        private static final Context INSTANCE = new Context();
    }
    private Connection dbConnection;

    public void setDBConnection(Connection connection) {
        this.dbConnection = connection;
    }

    public Connection getDBConnection() {
        return dbConnection;
    }

    //Main Menu
    private Menu mainMenu;

    public void setMainMenu(Menu menu) {
        this.mainMenu = menu;
    };

    public Menu mainMenu() {
        return mainMenu;
    }

    //Menu Drawer
    private Drawable drawer;

    public void setDrawer(Drawable drawer) {
        this.drawer = drawer;
    };

    public Drawable drawer() {
        return drawer;
    }

    //Session
    private Session session;

    public void setSession(Session session) {
        this.session = session;
    }

    public Session session() {
        return session;
    }

    public User userLoggedIn() {
        if (session() != null) {
            return session.user();
        }
        return null;
    }

    //Connection Factory
    private static ConnectionFactory cf = new ConnectionFactory();

    public static ConnectionFactory getConnectionFactory() {
        return cf;
    }
    private static void initializeDatabaseConnection() throws SQLException {
        Context context = Context.getInstance();
        ConnectionFactory cf = context.getConnectionFactory();
        DatabaseConnection dbc = cf.getDatabaseConnection();
        Connection connection = dbc.getConnection();
        context.setDBConnection(connection);
    }
}
