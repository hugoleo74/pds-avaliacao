package org.example.domain;

import org.example.dto.BrandDTO;
import org.example.dto.DTOable;

public class Brand implements DTOable {
    private String name;
    public Brand(String name) {
        this.name = name;
    }

    public String name() {
        return name;
    }

    @Override
    public BrandDTO toDTO() {
        BrandDTO dto = new BrandDTO.Builder()
                .withName(name())
                .build();
        return dto;
    }
}
