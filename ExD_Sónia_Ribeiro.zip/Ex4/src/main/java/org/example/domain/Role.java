package org.example.domain;

import org.example.dto.DTOable;
import org.example.dto.RoleDTO;

public class Role implements DTOable {

    private String role;

    public Role(String role) {
        this.role = role;
    }

    public String role() {
        return this.role;
    }

    @Override
    public RoleDTO toDTO() {
        RoleDTO dto = new RoleDTO.Builder()
                .withRole(role())
                .build();
        return dto;
    }
}
