package org.example.domain;

import org.example.dto.DTOable;
import org.example.dto.PhoneDTO;

public class Phone implements DTOable<PhoneDTO> {
    private Integer phoneNumber;

    public Integer phoneNumber() {
        return this.phoneNumber;
    }
    public Phone(Integer phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public PhoneDTO toDTO() {
        return new PhoneDTO.Builder()
                .withPhoneNumber(phoneNumber())
                .build();
    }
}
