package org.example.domain;

public class VaccinationCenter {
    private String name;
    private String adress;
    private int phoneNumber;
    private String emailAdress;
    private int faxNumber;
    private String websiteAdress;
    private int openingHours;
    private int closingHours;
    private int maxNumbVacPerHour;

    public VaccinationCenter(String name, String adress, int phoneNumber, String emailAdress, int faxNumber, String websiteAdress, int openingHours, int closingHours, int maxNumbVacPerHour) {
        this.name = name;
        this.adress = adress;
        this.phoneNumber = phoneNumber;
        this.emailAdress = emailAdress;
        this.faxNumber = faxNumber;
        this.websiteAdress = websiteAdress;
        this.openingHours = openingHours;
        this.closingHours = closingHours;
        this.maxNumbVacPerHour = maxNumbVacPerHour;
    }

//    public String name() {
//        return name;
//    }
//    public VaccineType vaccineType() {
//        return vaccineType;
//    }
}

