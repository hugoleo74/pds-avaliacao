package org.example.domain;

import org.example.auth.Email;
import org.example.dto.*;

import java.time.LocalTime;

public class Employee implements DTOable<EmployeeDTO> {

    private Integer employeeID;
    private String employee_Name;
    private Email employee_Email;
    private Role employee_Role;
    private Phone employee_PhoneNumber;


    public Integer employeeID () {
        return this.employeeID;
    }
    public String employee_Name() {
        return this.employee_Name;
    }
    public Email employee_Email() {
        return this.employee_Email;
    }
    public Role employee_Role() {
        return this.employee_Role;
    }
    public Phone employee_PhoneNumber() {
        return this.employee_PhoneNumber;
    }

    private Employee(final Employee.Builder builder) {
        this.employeeID = builder.employeeID;
        this.employee_Name = builder.employee_Name;
        this.employee_Email = builder.employee_Email;
        this.employee_Role = builder.employee_Role;
        this.employee_PhoneNumber = builder.employee_PhoneNumber;
    }

    public static class Builder {
        private Integer employeeID;
        private String employee_Name;
        private Email employee_Email;
        private Role employee_Role;
        private Phone employee_PhoneNumber;

        public Employee.Builder withId(final Integer employeeID) {
            this.employeeID = employeeID;
            return this;
        }
        public Employee.Builder withName(final String employee_Name) {
            this.employee_Name = employee_Name;
            return this;
        }
        public Employee.Builder withEmail(final Email employee_Email) {
            this.employee_Email = employee_Email;
            return this;
        }
        public Employee.Builder withRole(final Role employee_Role) {
            this.employee_Role = employee_Role;
            return this;
        }
        public Employee.Builder withPhone(final Phone employee_PhoneNumber) {
            this.employee_PhoneNumber = employee_PhoneNumber;
            return this;
        }

        public Employee build() {
            return new Employee(this);
        }
    }

    @Override
    public EmployeeDTO toDTO() {
        EmployeeDTO.Builder builder = new EmployeeDTO.Builder();
        if (employeeID() != null) {
            builder.withId(employeeID());
        }
        if (employee_Name() != null) {
            builder.withName(employee_Name());
        }
        if (employee_Email() != null) {
            builder.withEmailDTO((EmailDTO) employee_Email().toDTO());
        }
        if (employee_Role() != null) {
            builder.withRoleDTO((RoleDTO) employee_Role().toDTO());
        }
        if (employee_PhoneNumber() != null) {
            builder.withPhoneDTO((PhoneDTO) employee_PhoneNumber().toDTO());
        }

        return builder.build();
    }
}
