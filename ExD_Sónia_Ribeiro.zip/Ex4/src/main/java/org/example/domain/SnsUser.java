package org.example.domain;

public class SnsUser {
    private String name;
    private String birthDate;
    private String sex;
    private String postAddress;
    private int phoneNumber;
    private String emailAddress;
    private int citizenCardNumber;
    private int snsUserNumber;

    public SnsUser(String name, String birthDate, String sex, String postAddress, int phoneNumber, String emailAddress, int citizenCardNumber, int snsUserNumber){
        this.name=name;
        this.birthDate=birthDate;
        this.sex=sex;
        this.postAddress=postAddress;
        this.phoneNumber=phoneNumber;
        this.emailAddress=emailAddress;
        this.citizenCardNumber=citizenCardNumber;
        this.snsUserNumber=snsUserNumber;
    }
}

