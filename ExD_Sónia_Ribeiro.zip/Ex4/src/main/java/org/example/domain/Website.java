package org.example.domain;

import org.example.dto.DTOable;
import org.example.dto.WebsiteDTO;

public class Website implements DTOable<WebsiteDTO> {
    private String address;

    public String address() {
        return this.address;
    }

    public Website(String address) {
        this.address = address;
    }

    @Override
    public WebsiteDTO toDTO() {
        return new WebsiteDTO(address());
    }
}
