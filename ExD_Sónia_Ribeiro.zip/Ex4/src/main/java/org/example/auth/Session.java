package org.example.auth;

import java.util.Date;

public class Session {
    private Date logIn;
    private Date logOut;

}
