package org.example.controller;

import org.example.domain.VaccinationCenter;
import org.example.repository.Repositories;
import org.example.repository.VaccinationCenterRepository;

public class VaccinationCenterController {
    VaccinationCenterRepository vaccinationCenterRepository = Repositories.getInstance().vaccinationCenterRepository();
    private VaccinationCenter vaccinationCenter;

    public void createVaccinationCenter(String name, String adress, int phoneNumber, String emailAdress, int faxNumber, String websiteAdress, int openingHours, int closingHours, int maxNumbVacPerHour) {
        vaccinationCenter = vaccinationCenterRepository.createVaccinationCenter(name, adress, phoneNumber, emailAdress, faxNumber, websiteAdress, openingHours, closingHours, maxNumbVacPerHour);
    }
    public boolean confirm() {
        vaccinationCenterRepository.save(vaccinationCenter);
        return true;
    }
}
