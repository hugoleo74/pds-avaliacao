package org.example.controller;

import org.example.domain.SnsUser;
import org.example.repository.Repositories;
import org.example.repository.SnsUserRepository;

public class CreateSnsUserController {

    SnsUserRepository snsUserRepository = Repositories.getInstance().snsUserRepository();

    private SnsUser snsUser;

    public void createSnsUser(String name, String birthDate, String sex, String postAddress, int phoneNumber, String emailAddress, int citizenCardNumber, int snsUserNumber){
        snsUser=snsUserRepository.createSnsUser(name, birthDate, sex, postAddress, phoneNumber, emailAddress, citizenCardNumber, snsUserNumber);
    }

    public boolean confirm(){
        snsUserRepository.save(snsUser);
        return true;
    }
}
