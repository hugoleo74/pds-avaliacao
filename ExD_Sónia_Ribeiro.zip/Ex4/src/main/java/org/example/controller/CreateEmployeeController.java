package org.example.controller;

import org.example.domain.Employee;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;
import org.example.repository.EmployeeRepository;
import org.example.repository.Repositories;
import org.example.repository.RoleRepository;

import java.util.List;

public class CreateEmployeeController implements UIable {

    EmployeeRepository employeeRepository = Repositories.getInstance().employeeRepository();
    RoleRepository roleRepository = Repositories.getInstance().roleRepository();

    Employee employee;

    @Override
    public void register(DTO dto) throws Exception {
        employee = employeeRepository.createEmployee(dto);
    }

    @Override
    public boolean save() {
        return employeeRepository.save(employee);
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() {
        return employeeRepository.keyValueDTOList();
    }

}
