package org.example.controller;

import org.example.domain.Role;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;
import org.example.repository.Repositories;
import org.example.repository.RoleRepository;

import java.util.List;

public class RoleController implements UIable {

    RoleRepository roleRepository = Repositories.getInstance().roleRepository();

    Role role;

    @Override
    public void register(DTO dto) throws Exception {
        role = roleRepository.createRole(dto);
    }

    @Override
    public boolean save() {
        return roleRepository.save(role);
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() {
        return roleRepository.keyValueDTOList();
    }

}
