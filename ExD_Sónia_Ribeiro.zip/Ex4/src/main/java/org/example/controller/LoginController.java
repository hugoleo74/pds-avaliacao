package org.example.controller;


import org.example.auth.User;
import org.example.repository.Repositories;
import org.example.repository.UserRepository;
import org.example.session.Context;
import org.example.session.Session;

public class LoginController {
    //private final ApplicationSession applicationSession;

    private final UserRepository userRepository;

    public LoginController() {
        this.userRepository = Repositories.getInstance().userRepository();
    }

    public boolean logIn(String email, String  password) throws Exception {
        User user =  userRepository.userByEmail(email);
        if  ((user != null) && (user.hasPassword(password))) {
            Session session = new Session(user);
            Context.getInstance().setSession(session);
            return true;
        }
        return false;
    }


    public boolean logOut(User user) {
        if (user != null) {
            Context.getInstance().setSession(null);
            return true;
        }
        return false;
    }
}
