package org.example.controller;

import org.example.domain.Brand;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;
import org.example.repository.BrandRepository;
import org.example.repository.Repositories;

import java.util.List;

public class BrandController implements UIable {
    BrandRepository brandRepository = Repositories.getInstance().brandRepository();

    /*public List<Brand> brandList() {
        return brandRepository.brandList();
    }

     */

    Brand brand;
    /*public void createBrand(String name) {
        brand = brandRepository.createBrand(name);
    }

     */

    /*
    private VaccineTech vaccineTech;

    public void createVaccineTech(String name, String description) {
        vaccineTech = vaccineTechRepository.createVaccineTech(name, description);
    }

    public List<VaccineTech> vaccineTechList() {
        return vaccineTechRepository.vaccineTechList();
    }

    public String getVaccineTechName(int id) {
        return vaccineTechRepository.getById(id).name();
    }
*/
    /*public boolean confirm() {
        brandRepository.save(brand);
        return true;
    }

     */

    @Override
    public void register(DTO dto) {
        brand = brandRepository.createBrand(dto);
    }

    @Override
    public boolean save() {
        return brandRepository.save(brand);
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() {
        return brandRepository.keyValueDTOList();
    }


}

