package org.example.controller;

import org.example.domain.Vaccine;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;
import org.example.repository.BrandRepository;
import org.example.repository.Repositories;
import org.example.repository.VaccineRepository;
import org.example.repository.VaccineTypeRepository;

import java.util.List;

public class VaccineController implements UIable{
    VaccineRepository vaccineRepository = Repositories.getInstance().vaccineRepository();
    VaccineTypeRepository vaccineTypeRepository = Repositories.getInstance().vaccineTypeRepository();
    BrandRepository brandRepository = Repositories.getInstance().brandRepository();

    private Vaccine vaccine;


    @Override
    public void register(DTO dto) throws Exception {
        vaccine = vaccineRepository.createVaccine(dto);
    }

    @Override
    public boolean save() {
        return vaccineRepository.save(vaccine);
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() {
        return vaccineRepository.keyValueDTOList();
    }
}

    /*public void createVaccine(String vaccineTypeCode, String brandName, String vaccineName) {
        VaccineType vaccineType = vaccineTypeRepository.getByCode(vaccineTypeCode);
        Brand band = brandRepository.getByName(brandName);
        vaccine = vaccineRepository.createVaccine(vaccineName, vaccineType, band);
    }

     */
    /*public List<VaccineDTO> vaccineList() {
        List<Vaccine> vaccineList = vaccineRepository.vaccineList();
        List<VaccineDTO> vaccineDTOList = new ArrayList<>();
        VaccineDTO vaccineDTO = new VaccineDTO();
        for (Vaccine vaccine : vaccineList) {
            vaccineDTO.name = vaccine.name();
            vaccineDTO.vaccineTypeDTO.code = vaccine.vaccineType().code();
            vaccineDTO.vaccineTypeDTO.shortDescription = vaccine.vaccineType().shortDescription();
            vaccineDTO.vaccineTypeDTO.vaccineTechDTO.id = vaccine.vaccineType().vaccineTech().id();
            vaccineDTO.vaccineTypeDTO.vaccineTechDTO.name = vaccine.vaccineType().vaccineTech().name();
            vaccineDTO.vaccineTypeDTO.vaccineTechDTO.description = vaccine.vaccineType().vaccineTech().description();
            vaccineDTOList.add(vaccineDTO);
        }
        return vaccineDTOList;
    }
    /*
    public List<VaccineTech> vaccineTechList() {
        return vaccineTechRepository.vaccineTechList();
    }

    public String getVaccineTechName(int id) {
        return vaccineTechRepository.getById(id).name();
    }
    */
    /*public boolean confirm() {
        vaccineRepository.save(vaccine);
        return true;
    }
     */






