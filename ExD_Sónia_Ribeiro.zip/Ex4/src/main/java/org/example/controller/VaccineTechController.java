package org.example.controller;

import org.example.domain.VaccineTech;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;
import org.example.repository.Repositories;
import org.example.repository.VaccineTechRepository;

import java.util.List;

public class VaccineTechController implements UIable {
    VaccineTechRepository vaccineTechRepository = Repositories.getInstance().vaccineTechRepository();

    private VaccineTech vaccineTech;


    @Override
    public void register(DTO dto) throws Exception {
        vaccineTech = vaccineTechRepository.createVaccineTech(dto);
    }

    @Override
    public boolean save() {
        return vaccineTechRepository.save(vaccineTech);
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() {
        return vaccineTechRepository.keyValueDTOList();
    }
}

    /*public void createVaccineTech(String name, String description) {
        vaccineTech = vaccineTechRepository.createVaccineTech(name, description);
    }

    public List<VaccineTech> vaccineTechList() {
        return vaccineTechRepository.vaccineTechList();
    }

    public String getVaccineTechName(int id) {
        return vaccineTechRepository.getById(id).name();
    }

    public boolean confirm() {
        vaccineTechRepository.save(vaccineTech);
        return true;
    }
     */




