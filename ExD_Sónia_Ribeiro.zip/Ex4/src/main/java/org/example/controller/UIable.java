package org.example.controller;

import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;

import java.util.List;

public interface UIable {
    void register(DTO dto) throws Exception;
    boolean save();
    List<KeyValueDTO> keyValueDTOList();


}
