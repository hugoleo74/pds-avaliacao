package org.example.controller;

import org.example.domain.VaccineType;
import org.example.dto.DTO;
import org.example.dto.KeyValueDTO;
import org.example.repository.Repositories;
import org.example.repository.VaccineTypeRepository;

import java.util.List;

public class VaccineTypeController implements UIable {
    VaccineTypeRepository vaccineTypeRepository = Repositories.getInstance().vaccineTypeRepository();
    private VaccineType vaccineType;


    @Override
    public void register(DTO dto) throws Exception {
        vaccineType = vaccineTypeRepository.createVaccineType(dto);
    }

    @Override
    public boolean save() {
        return vaccineTypeRepository.save(vaccineType);
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() {
        return vaccineTypeRepository.keyValueDTOList();
    }
}

    /*public void createVaccineType(String code, String shortDescription, int vaccineTechId) {
        VaccineTechRepository vaccineTechRepository = Repositories.getInstance().vaccineTechRepository();
        VaccineTech vaccineTech = vaccineTechRepository.getById(vaccineTechId);

        this.vaccineType = vaccineTypeRepository.createVaccineType(code, shortDescription, vaccineTech);
    }

    public List<VaccineType> vaccineTypeList() {
        return vaccineTypeRepository.vaccineTypeList();
    }

    public boolean confirm() {
        vaccineTypeRepository.save(vaccineType);
        return true;
    }
     */





