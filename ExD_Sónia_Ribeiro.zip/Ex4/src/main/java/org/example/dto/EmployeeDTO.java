package org.example.dto;

import org.example.domain.Employee;
import org.example.domain.Role;

import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class EmployeeDTO implements DTO{
    private Integer employeeID;
    private String employee_Name;
    private EmailDTO employee_EmailDTO;
    private RoleDTO employee_RoleDTO;
    private PhoneDTO employee_PhoneNumberDTO;

    public Integer employeeID() {
        return this.employeeID;
    }

    public String employee_Name() {
        return this.employee_Name;
    }

    public EmailDTO employee_EmailDTO() {
        return this.employee_EmailDTO;
    }

    public RoleDTO employee_RoleDTO() {
        return this.employee_RoleDTO;
    }

    public PhoneDTO employee_PhoneNumberDTO() {
        return this.employee_PhoneNumberDTO;
    }



    private EmployeeDTO(final EmployeeDTO.Builder builder) {
        this.employeeID = builder.employeeID;
        this.employee_Name = builder.employee_Name;
        this.employee_EmailDTO = builder.employee_EmailDTO;
        this.employee_RoleDTO = builder.employee_RoleDTO;
        this.employee_PhoneNumberDTO = builder.employee_PhoneNumberDTO;
    }

    public static class Builder {
        private Integer employeeID;
        private String employee_Name;
        private EmailDTO employee_EmailDTO;
        private RoleDTO employee_RoleDTO;
        private PhoneDTO employee_PhoneNumberDTO;


        public EmployeeDTO.Builder withId(final Integer employeeID) {
            this.employeeID = employeeID;
            return this;
        }
        public EmployeeDTO.Builder withName(final String employee_Name) {
            this.employee_Name = employee_Name;
            return this;
        }
        public EmployeeDTO.Builder withEmailDTO(final EmailDTO employee_EmailDTO) {
            this.employee_EmailDTO = employee_EmailDTO;
            return this;
        }
        public EmployeeDTO.Builder withRoleDTO(final RoleDTO employee_RoleDTO) {
            this.employee_RoleDTO = employee_RoleDTO;
            return this;
        }
        public EmployeeDTO.Builder withPhoneDTO(final PhoneDTO employee_PhoneNumberDTO) {
            this.employee_PhoneNumberDTO = employee_PhoneNumberDTO;
            return this;
        }

        public EmployeeDTO build() {
            return new EmployeeDTO(this);
        }
    }
}

