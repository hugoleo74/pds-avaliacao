package org.example.dto;

public interface DTO {
}
