package org.example.dto;

public class KeyValueDTO {
    public String key;
    public String value;

    public KeyValueDTO(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
