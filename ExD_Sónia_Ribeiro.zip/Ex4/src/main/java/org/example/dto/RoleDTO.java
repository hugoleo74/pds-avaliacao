package org.example.dto;

public class RoleDTO implements DTO{
    private String role;

    public String role() {
        return this.role;
    }

    private RoleDTO(final RoleDTO.Builder builder) {
        this.role = builder.role;;
    }

    public static class Builder {
        private String role;

        public RoleDTO.Builder withRole(final String role) {
            this.role = role;
            return this;
        }

        public RoleDTO build() {
            return new RoleDTO(this);
        }
    }
}
