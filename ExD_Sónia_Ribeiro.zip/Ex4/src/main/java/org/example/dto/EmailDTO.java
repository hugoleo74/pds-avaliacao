package org.example.dto;

public class EmailDTO implements DTO {
    private String address;

    public String address() {
        return this.address;
    }

    public EmailDTO(final EmailDTO.Builder builder) {
        this.address = builder.address;
    }

    public static class Builder {
        private String address;

        public Builder withEmail(final String address) {
            this.address = address;
            return this;
        }

        public EmailDTO build() {
            return new EmailDTO(this);
        }
    }
}
