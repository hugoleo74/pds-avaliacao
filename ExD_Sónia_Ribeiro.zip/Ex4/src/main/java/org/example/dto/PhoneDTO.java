package org.example.dto;

public class PhoneDTO implements DTO{
    private Integer phoneNumber;

    public Integer phoneNumber() {
        return this.phoneNumber;
    }

    public PhoneDTO(final PhoneDTO.Builder builder) {
        this.phoneNumber = builder.phoneNumber;
    }

    public static class Builder {
        private Integer phoneNumber;

        public Builder withPhoneNumber(final Integer phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public PhoneDTO build() {
            return new PhoneDTO(this);
        }
    }
}
