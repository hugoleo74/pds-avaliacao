package org.example.dto;

public interface DTOable<T> {
    T toDTO();
}
