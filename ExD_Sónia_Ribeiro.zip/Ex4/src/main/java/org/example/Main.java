package org.example;

import org.example.db.ConnectionFactory;
import org.example.db.DatabaseConnection;
import org.example.dto.EmployeeDTO;
import org.example.dto.RoleDTO;
import org.example.session.Context;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;



public class Main {
    public static void main(String[] args) {
        try {
            initializeDatabaseConnection();
            Bootstrap bootstrap = new Bootstrap();
            bootstrap.run();

            Context.getInstance().drawer().draw(Context.getInstance().mainMenu());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (Context.getInstance().getDBConnection() != null) {
                    Context.getInstance().getDBConnection().close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void initializeDatabaseConnection() {
        try {
            ConnectionFactory cf = Context.getConnectionFactory();
            DatabaseConnection dbc = cf.getDatabaseConnection();
            Connection connection = dbc.getConnection();

            if (connection != null) {
                System.out.println("Connected to the database");
                Context.getInstance().setDBConnection(connection);
            } else {
                System.out.println("Failed to make the connection");
            }
        } catch (SQLException e) {

            System.err.println("Error initializing the database connection:");
            e.printStackTrace();
        }
    }
}