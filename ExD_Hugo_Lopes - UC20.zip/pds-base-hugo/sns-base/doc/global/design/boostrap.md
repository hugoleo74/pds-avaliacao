# Bootstrap

*When the application starts data is loaded allowing to proceed with the authentication. After a successful user authentication, the user can select the available options.*

**Bootstrappers**

- Roles
- Users
- Menus