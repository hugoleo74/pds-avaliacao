# Glossary

**Terms, Expressions and Acronyms (TEA) must be organized alphabetically.**

| **_TEA_** (EN)  |  **_Description_** (EN)                                           |                                       
|:------------------------|:--------------------------------------------|
| **Clerk** |  Person responsible for carrying out various business supporting activities on the system. |
| **CLK** |  Acronym for _Clerk_.|
| **...** |  ...|








