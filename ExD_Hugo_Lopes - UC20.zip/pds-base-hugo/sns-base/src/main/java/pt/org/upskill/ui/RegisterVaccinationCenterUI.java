package pt.org.upskill.ui;

public class RegisterVaccinationCenterUI extends UI {

}
