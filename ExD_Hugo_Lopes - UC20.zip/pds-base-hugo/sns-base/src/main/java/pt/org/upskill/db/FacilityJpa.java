package pt.org.upskill.db;

import pt.org.upskill.domain.Facility;

import javax.persistence.EntityManager;


public class FacilityJpa implements PersistableObjectJpa {

    @Override
    public boolean save(EntityManager connection, Object object) {
        connection.getTransaction().begin();
        connection.persist(object);
        connection.getTransaction().commit();
        return true;
    }

    @Override
    public boolean delete(EntityManager connection, Object object) {
        return false;
    }

    @Override
    public Object getById(EntityManager connection, Object o) {
        return null;
    }

    @Override
    public Object getByBusinessId(EntityManager connection, Object businessId) {
        return null;
    }
}
