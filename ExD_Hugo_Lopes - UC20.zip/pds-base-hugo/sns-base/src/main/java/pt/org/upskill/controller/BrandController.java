package pt.org.upskill.controller;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.domain.Brand;
import pt.org.upskill.dto.DTO;
import pt.org.upskill.dto.KeyValueDTO;
import pt.org.upskill.jpa.JpaRepository;
import pt.org.upskill.repository.Repositories;
import pt.org.upskill.repository.BrandRepository;

import javax.persistence.EntityManager;
import java.util.List;

public class BrandController implements UIable {
    BrandRepository brandRepository = new BrandRepository();

    Brand brand;

    @Override
    public void register(DTO dto) {
        brand = brandRepository.createBrand(dto);
    }

    @Override
    public boolean save() {
        /*
        brandRepository.beginTransaction();
        try {
            brandRepository.save(brand);
            brandRepository.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            brandRepository.rollback();
            return false;
        }
         */
        EntityManager em = JpaRepository.entityManager();
        try {
            em.getTransaction().begin();
            em.persist(brand);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
            return false;
        }
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() {
        return brandRepository.keyValueDTOList();
    }
}
