package pt.org.upskill.repository;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.db.VaccineDB;
import pt.org.upskill.domain.Brand;
import pt.org.upskill.domain.Vaccine;
import pt.org.upskill.domain.VaccineType;
import pt.org.upskill.dto.DTO;
import pt.org.upskill.dto.KeyValueDTO;
import pt.org.upskill.dto.VaccineDTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VaccineRepository extends JdbcRepository implements PersistableRepo<Vaccine, Integer, String> {

    public Vaccine createVaccine(DTO dto) {
        VaccineDTO vaccineDTO = (VaccineDTO) dto;
        VaccineTypeRepository vaccineTypeRepository = Repositories.getInstance().vaccineTypeRepository();
        BrandRepository brandRepository = Repositories.getInstance().brandRepository();
        return new Vaccine.Builder()
                .withName(vaccineDTO.name())
                .withVaccineType(vaccineTypeRepository.getByBusinessId(vaccineDTO.vaccineTypeDTO().code()))
                .withBrand(brandRepository.getById(vaccineDTO.brandDTO().name()))
                .build();
    }

    public List<KeyValueDTO> keyValueDTOList() {
        List<KeyValueDTO> dtoList = new ArrayList<>();
        for (Vaccine item : getAll()) {
            VaccineDTO dto = item.toDTO();
            dtoList.add(new KeyValueDTO(dto.id().toString(), dto.name() + " -  Type: " + dto.vaccineTypeDTO().code()));
        }
        return dtoList;
    }

    @Override
    public boolean save(Vaccine object) {
        try {
            VaccineDB vaccineDB = new VaccineDB();
            vaccineDB.save(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean delete(Vaccine object) {
        try {
            VaccineDB vaccineDB = new VaccineDB();
            vaccineDB.delete(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public Vaccine getById(Integer id) {
        return new VaccineDB().getById(conn, id);
    }

    @Override
    public Vaccine getByBusinessId(String businessId) {
        return new VaccineDB().getByBusinessId(conn, businessId);
    }

    @Override
    public List<Vaccine> getAll() {
        try {
            List<Vaccine> list = new ArrayList<>();
            String sqlCmd = "select * from Vaccine";
            try (PreparedStatement ps = conn.prepareStatement(sqlCmd)) {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    list.add(buildFromResultSet(rs));
                }
                return list;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VaccineRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Vaccine buildFromResultSet(ResultSet resultSet) {
        VaccineTypeRepository vaccineTypeRepository = new VaccineTypeRepository();
        BrandRepository brandRepository = new BrandRepository();
        try {
            VaccineType vaccineType = vaccineTypeRepository.getById(resultSet.getString("vaccinetype_code"));
            Brand brand = brandRepository.getById(resultSet.getString("brand_name"));
            return new Vaccine.Builder()
                    .withId(resultSet.getInt("id"))
                    .withName(resultSet.getString("name"))
                    .withVaccineType(vaccineType)
                    .withBrand(brand)
                    .build();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}