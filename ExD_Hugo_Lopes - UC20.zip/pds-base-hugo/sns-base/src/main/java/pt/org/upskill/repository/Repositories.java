package pt.org.upskill.repository;

import pt.org.upskill.domain.*;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

public class Repositories {

    private static final Repositories instance = new Repositories();
    private Repositories() {  }
    public static Repositories getInstance() {
        return instance;
    }

    RoleRepository roleRepository = new RoleRepository();
    UserRepository userRepository = new UserRepository();

    public RoleRepository roleRepository() {
        return roleRepository;
    }
    public UserRepository userRepository() {
        return userRepository;
    }

    //Your code here
    VaccineTechRepository vaccineTechRepository = new VaccineTechRepository();
    VaccineTypeRepository vaccineTypeRepository = new VaccineTypeRepository();
    VaccineRepository vaccineRepository = new VaccineRepository();
    BrandRepository brandRepository = new BrandRepository();
    //SnsUserRepository snsUserRepository = new SnsUserRepository();
    UserSNSRepository userSNSRepository = new UserSNSRepository();
    FacilityRepository facilityRepository = new FacilityRepository();

    public VaccineTechRepository vaccineTechRepository() {return vaccineTechRepository;}
    public VaccineTypeRepository vaccineTypeRepository() {return vaccineTypeRepository;}
    public VaccineRepository vaccineRepository() {return vaccineRepository;}
    public BrandRepository brandRepository() {return brandRepository;}
    //public SnsUserRepository snsUserRepository(){ return snsUserRepository;}
    public UserSNSRepository userSNSRepository(){
        return userSNSRepository;
    }
    public FacilityRepository facilityRepository() {return facilityRepository;}
}