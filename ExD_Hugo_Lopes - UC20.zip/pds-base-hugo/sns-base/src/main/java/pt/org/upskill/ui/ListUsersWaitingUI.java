package pt.org.upskill.ui;

public class ListUsersWaitingUI extends UI {
}
