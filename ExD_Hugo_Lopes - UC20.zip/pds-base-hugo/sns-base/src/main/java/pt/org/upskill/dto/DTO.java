package pt.org.upskill.dto;

public interface DTO {
}
