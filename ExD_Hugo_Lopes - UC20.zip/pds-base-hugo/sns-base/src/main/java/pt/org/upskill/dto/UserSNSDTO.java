package pt.org.upskill.dto;

import java.sql.Date;

public class UserSNSDTO implements DTO {
    private Integer id;
    private String name;
    private String birthDate;
    private String sex;
    private String postalAddress;
    private Integer phoneNumber;
    private String emailAddress;
    private String citizenCardNumber;
    private Integer userSNSNumber;

    public Integer id() {
        return this.id;
    }

    public String name() {
        return this.name;
    }

    public String birthDate() {
        return this.birthDate;
    }

    public String sex() {
        return this.sex;
    }

    public String postalAddress() {
        return this.postalAddress;
    }

    public Integer phoneNumber() {
        return this.phoneNumber;
    }

    public String emailAddress() {
        return this.emailAddress;
    }

    public String citizenCardNumber() {
        return this.citizenCardNumber;
    }

    public Integer userSNSNumber() {
        return this.userSNSNumber;
    }

    private UserSNSDTO(final UserSNSDTO.Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.birthDate = builder.birthDate;
        this.sex = builder.sex;
        this.postalAddress = builder.postalAddress;
        this.phoneNumber = builder.phoneNumber;
        this.emailAddress = builder.emailAddress;
        this.citizenCardNumber = builder.citizenCardNumber;
        this.userSNSNumber = builder.userSNSNumber;

    }

    public static class Builder {
        private Integer id;
        private String name;
        private String birthDate;
        private String sex;
        private String postalAddress;
        private Integer phoneNumber;
        private String emailAddress;
        private String citizenCardNumber;
        private Integer userSNSNumber;

        public Builder withId(final Integer id) {
            this.id = id;
            return this;
        }

        public Builder withName(final String name) {
            this.name = name;
            return this;
        }

        public Builder withDate(final String birthDate) {
            this.birthDate = birthDate;
            return this;
        }

        public Builder withSex(final String sex) {
            this.sex = sex;
            return this;
        }

        public Builder withPostalAddress(final String postalAddress) {
            this.postalAddress = postalAddress;
            return this;
        }

        public Builder withPhoneNumber(final Integer phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder withEmailAddress(final String emailAddress) {
            this.emailAddress = emailAddress;
            return this;
        }

        public Builder withCitizenCardNumber(final String citizenCardNumber) {
            this.citizenCardNumber = citizenCardNumber;
            return this;
        }

        public Builder withUserSNSNumber(final Integer userSNSNumber) {
            this.userSNSNumber = userSNSNumber;
            return this;
        }

        public UserSNSDTO build() {
            return new UserSNSDTO(this);
        }
    }
}