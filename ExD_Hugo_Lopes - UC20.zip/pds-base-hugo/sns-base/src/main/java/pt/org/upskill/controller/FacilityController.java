package pt.org.upskill.controller;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.domain.Facility;
import pt.org.upskill.dto.DTO;
import pt.org.upskill.dto.KeyValueDTO;
import pt.org.upskill.jpa.JpaRepository;
import pt.org.upskill.repository.FacilityRepository;

import javax.persistence.EntityManager;
import java.util.List;

public class FacilityController implements UIable {
    FacilityRepository facilityRepository = new FacilityRepository();

    Facility facility;
    @Override
    public void register(DTO dto) throws Exception {
        facility = facilityRepository.createFacility(dto);
    }

    @Override
    public boolean save() {
        /*
        try {
            facilityRepository.beginTransaction();
            facilityRepository.save(facility);
            facilityRepository.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            facilityRepository.rollback();
            return false;
        }
         */
        EntityManager em = JpaRepository.entityManager();
        try {
            em.getTransaction().begin();
            em.persist(facility);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
            return false;
        }
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() {
        return facilityRepository.keyValueDTOList();
    }
}
