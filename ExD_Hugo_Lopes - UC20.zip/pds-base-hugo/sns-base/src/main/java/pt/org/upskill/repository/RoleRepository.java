package pt.org.upskill.repository;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.db.RoleDB;
import pt.org.upskill.domain.*;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RoleRepository extends JdbcRepository implements PersistableRepo<Role, String, String> {
    public static final String ROLE_ADMIN = "ADMINISTRATOR";
    public static final String ROLE_NURSE = "NURSE";
    public static final String ROLE_SNSUSER = "SNSUSER";
    public static final String ROLE_RECEPTIONIST = "RECEPTIONIST";

    @Override
    public boolean save(Role object) {
        try {
            RoleDB roleDB = new RoleDB();
            roleDB.save(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean delete(Role object) {
        try {
            RoleDB roleDB = new RoleDB();
            roleDB.delete(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public Role getById(String id) {
        try {
            RoleDB roleDB = new RoleDB();
            return roleDB.getById(conn, id);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Role getByBusinessId(String businessId) {
        return getById(businessId);
    }

    @Override
    public List<Role> getAll() {
        try {
            List<Role> roleList = new ArrayList<>();
            String sqlCmd = "select * from Role";
            try (PreparedStatement ps = conn.prepareStatement(sqlCmd)) {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    roleList.add(buildFromResultSet(rs));
                }
                return roleList;
            }
        } catch (SQLException ex) {
            Logger.getLogger(RoleRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Role buildFromResultSet(ResultSet resultSet) {
        try {
            return new Role(resultSet.getString("name"));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    //</PersistableRepo implementation>
}
