package pt.org.upskill.db;

import pt.org.upskill.domain.Facility;
import pt.org.upskill.repository.FacilityRepository;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FacilityDB implements PersistableObjectJdbc<Facility, Integer, Integer> {

    @Override
    public boolean save(Connection connection, Facility object) {
        String sqlCmd;
        sqlCmd = "select * from Facility where id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
            ps.setInt(1, object.id());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    sqlCmd = "update Facility set name = ?"+
                            ", address_streetname = ?, address_postalcode = ?, address_cityname = ?"+
                            ", phone = ?, fax = ?, email = ?, website = ?"+
                            ", openinghour = ?, closinghour = ?, maxvaccinesperhour = ?"+
                            " where id = ?";
                }
                else {
                    sqlCmd = "insert into Facility(name"+
                            ", address_streetname, address_postalcode, address_cityname"+
                            ", phone, fax, email, website"+
                            ", openinghour, closinghour, maxvaccinesperhour"+
                            ", id) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                }
                //
                try (PreparedStatement ps2 = connection.prepareStatement(sqlCmd)) {
                    ps2.setString(1, object.name());
                    if (object.address() == null) {
                        ps2.setString(2, null);
                        ps2.setString(3, null);
                        ps2.setString(4, null);
                    } else {
                        ps2.setString(2, object.address().streetName());
                        ps2.setString(3, object.address().postalCode());
                        ps2.setString(4, object.address().cityName());
                    }
                    if (object.phone() == null) {
                        ps2.setString(5, null);
                    } else {
                        ps2.setString(5, object.phone().phoneNumber());
                    }
                    if (object.fax() == null) {
                        ps2.setString(6, null);
                    } else {
                        ps2.setString(6, object.fax().phoneNumber());
                    }
                    if (object.email() == null) {
                        ps2.setString(7, null);
                    } else {
                        ps2.setString(7, object.email().address());
                    }
                    if (object.website() == null) {
                        ps2.setString(8, null);
                    } else {
                        ps2.setString(8, object.website().address());
                    }
                    if (object.openingHour() == null) {
                        ps2.setNull(9, Types.DOUBLE);
                    } else {
                        ps2.setDouble(9, object.openingHour());
                    }
                    if (object.closingHour() == null) {
                        ps2.setNull(10, Types.DOUBLE);
                    } else {
                        ps2.setDouble(10, object.closingHour());
                    }
                    if (object.maxVaccinesPerHour() == null) {
                        ps2.setNull(11, Types.INTEGER);
                    } else {
                        ps2.setInt(11, object.maxVaccinesPerHour());
                    }
                    ps2.setInt(12, object.id());
                    ps2.executeUpdate();
                    return true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return true;
        }
    }

    @Override
    public boolean delete(Connection connection, Facility object) {
        try {
            String sqlCmd;
            sqlCmd = "delete from Facility where id = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setInt(1, object.id());
                ps.executeUpdate();
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    @Override
    public Facility getById(Connection connection, Integer id) {
        try {
            String sqlCmd;
            sqlCmd = "select * from Facility where id = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new FacilityRepository().buildFromResultSet(rs);
                }
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Facility getByBusinessId(Connection connection, Integer businessId) {
        return getById(connection, businessId);
    }

}
