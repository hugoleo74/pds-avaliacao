package pt.org.upskill.repository;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.db.BrandDB;
import pt.org.upskill.domain.*;
import pt.org.upskill.dto.BrandDTO;
import pt.org.upskill.dto.DTO;
import pt.org.upskill.dto.KeyValueDTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BrandRepository extends JdbcRepository implements PersistableRepo<Brand, String, String> {

    public Brand createBrand(DTO dto) {
        BrandDTO brandDTO = (BrandDTO) dto;
        return new Brand(brandDTO.name());
    }

    public List<KeyValueDTO> keyValueDTOList() {
        List<KeyValueDTO> dtoList = new ArrayList<>();
        for (Brand item : getAll()) {
            BrandDTO dto = item.toDTO();
            dtoList.add(new KeyValueDTO(dto.name(), ""));
        }
        return dtoList;
    }

    @Override
    public boolean save(Brand object) {
        try {
            BrandDB brandDB = new BrandDB();
            brandDB.save(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean delete(Brand object) {
        try {
            BrandDB brandDB = new BrandDB();
            brandDB.delete(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public Brand getById(String id) {
        return new BrandDB().getById(conn, id);
    }

    @Override
    public Brand getByBusinessId(String businessId) {
        return new BrandDB().getById(conn, businessId);
    }

    @Override
    public List<Brand> getAll() {
        try {
            List<Brand> list = new ArrayList<>();
            String sqlCmd = "select * from Brand";
            try (PreparedStatement ps = conn.prepareStatement(sqlCmd)) {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    list.add(buildFromResultSet(rs));
                }
                return list;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BrandRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Brand buildFromResultSet(ResultSet resultSet) {
        try {
            return new Brand(resultSet.getString("name"));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}