package pt.org.upskill.ui;

public class AboutUI extends UI {

    public AboutUI() {
    }

    public void run() {
        System.out.println("\nAbout\n-----");
        System.out.println("  Version 1.0");
        System.out.println("  Developed by <student names>");
        System.out.println("  Copyright © 2024 UPskill");
    }
}