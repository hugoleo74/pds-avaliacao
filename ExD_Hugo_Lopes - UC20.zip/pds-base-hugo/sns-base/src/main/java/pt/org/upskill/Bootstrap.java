package pt.org.upskill;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.auth.Email;
import pt.org.upskill.auth.Password;
import pt.org.upskill.auth.User;
import pt.org.upskill.domain.Address;
import pt.org.upskill.domain.Facility;
import pt.org.upskill.domain.Phone;
import pt.org.upskill.domain.Role;
import pt.org.upskill.jpa.JpaRepository;
import pt.org.upskill.repository.FacilityRepository;
import pt.org.upskill.repository.Repositories;
import pt.org.upskill.repository.RoleRepository;
import pt.org.upskill.repository.UserRepository;
import pt.org.upskill.session.Context;
import pt.org.upskill.ui.*;
import pt.org.upskill.ui.menu.Drawable;
import pt.org.upskill.ui.menu.Menu;
import pt.org.upskill.ui.menu.MenuDrawer;

import javax.persistence.EntityManager;
import java.sql.Time;
import java.time.LocalTime;

import static pt.org.upskill.repository.RoleRepository.*;

public class Bootstrap implements Runnable {

    //Add some task categories to the repository as bootstrap
    public void run() {
        addRoles();
        addUsers();
        addMenus();
        addFacilities();
    }

    private void addRoles() {
        //TODO: add application user roles here
        RoleRepository roleRepository = new RoleRepository();

        roleRepository.beginTransaction();
        try {
            roleRepository.save(new Role(ROLE_ADMIN));
            roleRepository.save(new Role(ROLE_NURSE));
            roleRepository.save(new Role(ROLE_RECEPTIONIST));
            roleRepository.save(new Role(ROLE_SNSUSER));
            roleRepository.commit();
        } catch (Exception e) {
            e.printStackTrace();
            roleRepository.rollback();;
        }
    }

    private void addUsers() {
        //TODO: add Authentication users here: should be created for each user in the organization
        RoleRepository roleRepository = new RoleRepository();
        UserRepository userRepository = new UserRepository();

        userRepository.beginTransaction();
        try {
            userRepository.save(new User("adm", roleRepository.getById(ROLE_ADMIN), new Email("admin@upskill.pt"), new Password("admin")));
            userRepository.save(new User("nur", roleRepository.getById(ROLE_NURSE), new Email("nurse@upskill.pt"), new Password("nurse")));
            userRepository.save(new User("rec", roleRepository.getById(ROLE_RECEPTIONIST), new Email("receptionist@upskill.pt"), new Password("receptionist")));
            userRepository.save(new User("usr", roleRepository.getById(ROLE_SNSUSER), new Email("snsuser@upskill.pt"), new Password("snsuser")));
            userRepository.commit();
        } catch (Exception e) {
            e.printStackTrace();
            userRepository.rollback();;
        }
    }

    private void addFacilities() {
        try {
            Facility f1 = new Facility.Builder()
                    .withId(1)
                    .withName("Centro de Saúde de Amarante")
                    .withAddress(new Address("Rua X", "4600-011", "Amarante"))
                    .withPhone(new Phone("255 123 456"))
                    .withEmail(new Email("csa@csa.pt"))
                    .withOpeningHour(9.0)
                    .withClosingingHour(19.5)
                    .withMaxVaccinesPerHour(120)
                    .build();
            Facility f2 = new Facility.Builder()
                    .withId(2)
                    .withName("Centro de Saúde do Porto")
                    .withAddress(new Address("Rua da saúde", "4000-311", "Porto"))
                    .build();
            Facility f3 = new Facility.Builder()
                    .withId(3)
                    .withName("Centro de Saúde de Braga")
                    .build();

            //Jdbc
            FacilityRepository facilityRepository = Repositories.getInstance().facilityRepository();
            try {
                facilityRepository.beginTransaction();
                facilityRepository.save(f1);
                facilityRepository.save(f2);
                facilityRepository.save(f3);
                facilityRepository.commit();
            } catch (Exception e) {
                e.printStackTrace();
                facilityRepository.rollback();
            }

            //Jpa
            /*
            EntityManager em = JpaRepository.entityManager();
            try {
                em.getTransaction().begin();
                em.persist(f1);
                em.persist(f2);
                em.persist(f3);
                em.getTransaction().commit();
            } catch (Exception e) {
                e.printStackTrace();
                em.getTransaction().rollback();;
            }
            */
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addMenus() {
        //This is where we define the menu structure and respective permissions.
        RoleRepository roleRepository = Repositories.getInstance().roleRepository();

        Menu menu;

        Drawable drawer = new MenuDrawer();
        Context.getInstance().setDrawer(drawer);

        Menu mainMenu = new Menu(null, 1,"Main Menu", null);
        Context.getInstance().setMainMenu(mainMenu);

        //Everyone
        Menu menuLogin = new Menu(Context.getInstance().mainMenu(), 1,"Login", new LoginUI());
        menu = new Menu(Context.getInstance().mainMenu(), 2,"Logout", new LogoutUI());
        menu = new Menu(Context.getInstance().mainMenu(), 9,"About", new AboutUI());

        //Admin
        //menu = new Menu(menuLogin, 1, "Register User", new CreateUserUI());
        //menu.addPermission((Role) roleRepository.roleByName(ROLE_ADMIN));
        menu = new Menu(menuLogin, 2, "Register Vaccine Technology", new RegisterVaccineTechUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_ADMIN));
        menu = new Menu(menuLogin, 3, "Register Vaccine Type", new RegisterVaccineTypeUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_ADMIN));
        menu = new Menu(menuLogin, 4, "Register Brand", new RegisterBrandUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_ADMIN));
        menu = new Menu(menuLogin, 5, "Register Vaccine", new RegisterVaccineUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_ADMIN));
        //menu = new Menu(menuLogin, 5, "Register Vaccination Center", new RegisterVaccinationCenterUI());
        //menu.addPermission((Role) roleRepository.roleByName(ROLE_ADMIN));
        //menu = new Menu(menuLogin, 11, "List Employees With Role", new ListEmployeesWithRoleUI());
        //menu.addPermission((Role) roleRepository.roleByName(ROLE_ADMIN));
        menu = new Menu(menuLogin, 12, "List Vaccine Technologies", new ListVaccineTechsUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_ADMIN));
        menu = new Menu(menuLogin, 13, "List Vaccine Types", new ListVaccineTypesUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_ADMIN));
        menu = new Menu(menuLogin, 14, "List Vaccines", new ListVaccinesUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_ADMIN));

        //Receptionist
        menu = new Menu(menuLogin, 1, "Register SNS User", new RegisterUserSNSUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_RECEPTIONIST));
        menu = new Menu(menuLogin, 2, "Schedule Vaccination", new ScheduleVaccinationOnBehalfOfUserUI());
        menu.addPermission((Role) roleRepository.getById(ROLE_RECEPTIONIST));
        //menu = new Menu(menuLogin, 3, "Register SNS User Arrival", new RegisterUserArrivalUI());
        //menu.addPermission((Role) roleRepository.roleByName(ROLE_RECEPTIONIST));

        //SNS USer
        //menu = new Menu(menuLogin, 1, "Schedule Vaccination", new ScheduleVaccinationUI());
        //menu.addPermission((Role) roleRepository.roleByName(ROLE_RECEPTIONIST));

        //Nurse
        //menu = new Menu(menuLogin, 1, "List User Waiting", new ListUsersWaitingUI());
        //menu.addPermission((Role) roleRepository.roleByName(ROLE_NURSE));
    }
}