package pt.org.upskill.controller;

public class UserController {
}
