package pt.org.upskill.ui;

public class ListEmployeesWithRoleUI extends UI {
}
