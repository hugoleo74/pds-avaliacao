package pt.org.upskill.db;

import javax.persistence.EntityManager;

public interface PersistableObjectJpa <P, TId, TBid> {
    boolean save(EntityManager connection, P object);
    boolean delete(EntityManager connection, P object);
    P getById(EntityManager connection, TId id);
    P getByBusinessId(EntityManager connection, TBid businessId);
}
