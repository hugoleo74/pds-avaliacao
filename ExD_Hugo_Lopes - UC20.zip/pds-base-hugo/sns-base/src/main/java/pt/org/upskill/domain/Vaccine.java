package pt.org.upskill.domain;

import pt.org.upskill.dto.*;

import javax.persistence.*;

@Entity
public class Vaccine implements DTOable<VaccineDTO> {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;
    private String name;
    @ManyToOne
    private VaccineType vaccineType;
    @ManyToOne
    private Brand brand;

    public Integer id() {
        return this.id;
    }
    public String name() {
        return name;
    }
    public VaccineType vaccineType() {
        return vaccineType;
    }
    public Brand brand() {
        return this.brand;
    }

    private Vaccine(final Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.vaccineType = builder.vaccineType;
        this.brand = builder.brand;
    }

    public static class Builder {

        private Integer id;
        private String name;
        private VaccineType vaccineType;
        private Brand brand;

        public Builder withId(final Integer id) {
            this.id = id;
            return this;
        }
        public Builder withName(final String name) {
            this.name = name;
            return this;
        }
        public Builder withVaccineType(final VaccineType vaccineType) {
            this.vaccineType = vaccineType;
            return this;
        }
        public Builder withBrand(final Brand brand) {
            this.brand = brand;
            return this;
        }

        public Vaccine build() {
            return new Vaccine(this);
        }
    }

    @Override
    public VaccineDTO toDTO() {
        VaccineDTO.Builder builder = new VaccineDTO.Builder();
        builder.withId(id());
        builder.withName(name());
        if (vaccineType() != null) {
            builder.withVaccineTypeDTO(vaccineType().toDTO());
        } else {
            builder.withVaccineTypeDTO(null);
        }
        if (brand() != null) {
            builder.withBrandDTO(brand().toDTO());
        } else {
            builder.withBrandDTO(null);
        }
        return builder.build();
    }

    //Jpa
    protected Vaccine() {}
}
