package pt.org.upskill.controller;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.domain.VaccineTech;
import pt.org.upskill.dto.*;
import pt.org.upskill.jpa.JpaRepository;
import pt.org.upskill.repository.VaccineTechRepository;

import javax.persistence.EntityManager;
import java.util.List;

public class VaccineTechController implements UIable{
    VaccineTechRepository vaccineTechRepository = new VaccineTechRepository();

    private VaccineTech vaccineTech;

    @Override
    public void register(DTO dto) {
        vaccineTech = vaccineTechRepository.createVaccineTech(dto);
    }

    @Override
    public boolean save() {
        //Jbdc
        /*
        try {
          vaccineTechRepository.beginTransaction();
          vaccineTechRepository.save(vaccineTech);
          vaccineTechRepository.commit();
          return true;
        } catch (Exception e) {
            e.printStackTrace();
            vaccineTechRepository.rollback();
            return false;
        }
         */
        EntityManager em = JpaRepository.entityManager();
        try {
            em.getTransaction().begin();
            em.persist(vaccineTech);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
            return false;
        }
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() { return vaccineTechRepository.keyValueDTOList(); }
}
