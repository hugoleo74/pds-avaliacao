package pt.org.upskill.controller;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.domain.Vaccine;
import pt.org.upskill.dto.DTO;
import pt.org.upskill.dto.KeyValueDTO;
import pt.org.upskill.jpa.JpaRepository;
import pt.org.upskill.repository.VaccineRepository;

import javax.persistence.EntityManager;
import java.util.List;

public class VaccineController implements UIable {
    VaccineRepository vaccineRepository = new VaccineRepository();

    private Vaccine vaccine;

    @Override
    public void register(DTO dto) {
        vaccine = vaccineRepository.createVaccine(dto);
    }

    @Override
    public boolean save() {
        /*
        try {
            vaccineRepository.beginTransaction();
            vaccineRepository.save(vaccine);
            vaccineRepository.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            vaccineRepository.rollback();
            return false;
        }
         */
        EntityManager em = JpaRepository.entityManager();
        try {
            em.getTransaction().begin();
            em.persist(vaccine);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
            return false;
        }
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() { return vaccineRepository.keyValueDTOList(); }

}
