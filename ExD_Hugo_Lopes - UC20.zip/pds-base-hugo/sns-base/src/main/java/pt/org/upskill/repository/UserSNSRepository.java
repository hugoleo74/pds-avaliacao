package pt.org.upskill.repository;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */


import pt.org.upskill.db.UserSNSDB;
import pt.org.upskill.domain.UserSNS;

import pt.org.upskill.dto.DTO;
import pt.org.upskill.dto.KeyValueDTO;
import pt.org.upskill.dto.UserSNSDTO;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserSNSRepository extends JdbcRepository implements PersistableRepo<UserSNS, Integer, String> {



    public UserSNS createUserSNS(DTO dto) {
        UserSNSDTO userSNSDTO = (UserSNSDTO) dto;
        return new UserSNS(userSNSDTO.id(), userSNSDTO.name(), userSNSDTO.birthDate(), userSNSDTO.sex(), userSNSDTO. postalAddress(), userSNSDTO.phoneNumber(), userSNSDTO.emailAddress(), userSNSDTO.citizenCardNumber(), userSNSDTO.userSNSNumber());
    }

    public List<KeyValueDTO> keyValueDTOList() {
        List<KeyValueDTO> dtoList = new ArrayList<>();
        for (UserSNS item : getAll()) {
            UserSNSDTO dto = item.toDTO();
            dtoList.add(new KeyValueDTO(dto.id().toString(), dto.name()));
        }
        return dtoList;
    }

    @Override
    public boolean save(UserSNS object) {
        try {
            UserSNSDB userSNSDB = new UserSNSDB();
            userSNSDB.save(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean delete(UserSNS object) {
        try {
            UserSNSDB userSNSDB = new UserSNSDB();
            userSNSDB.delete(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public UserSNS getById(Integer id) {
        return new UserSNSDB().getById(conn, id);
    }

    @Override
    public UserSNS getByBusinessId(String businessId) {
        return new UserSNSDB().getByBusinessId(conn, businessId);
    }

    @Override
    public List<UserSNS> getAll() {
        try {
            List<UserSNS> list = new ArrayList<>();
            String sqlCmd = "select * from UserSNS";
            try (PreparedStatement ps = conn.prepareStatement(sqlCmd)) {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    list.add(buildFromResultSet(rs));
                }
                return list;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserSNSRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public UserSNS buildFromResultSet(ResultSet resultSet) {
        try {
            return new UserSNS(resultSet.getInt("id")
                    , resultSet.getString("name")
                    , resultSet.getString("birthDate")
                    , resultSet.getString("sex")
                    , resultSet.getString("postalAddress")
                    , resultSet.getInt("phoneNumber")
                    , resultSet.getString("emailAddress")
                    , resultSet.getString("citizenCardNumber")
                    , resultSet.getInt("userSNSNumber"));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}