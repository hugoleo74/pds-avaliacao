package pt.org.upskill.domain;

import pt.org.upskill.auth.Email;
import pt.org.upskill.dto.*;

import javax.persistence.*;

@Entity
public class Facility implements DTOable<FacilityDTO> {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="id")
    private Integer id;
    private String name;
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "streetName", column = @Column(name = "address_streetname")),
            @AttributeOverride(name = "postalCode", column = @Column(name = "address_postalcode")),
            @AttributeOverride(name = "cityName", column = @Column(name = "address_cityname"))
    })
    private Address address;
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "phoneNumber", column = @Column(name = "phone"))
    })
    private Phone phone;
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "address", column = @Column(name = "email"))
    })
    private Email email;
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "phoneNumber", column = @Column(name = "fax"))
    })
    private Phone fax;
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "address", column = @Column(name = "website"))
    })
    private Website website;
    private Double openingHour;
    private Double closingHour;
    private Integer maxVaccinesPerHour;

    public Integer id() {
        return this.id;
    }
    public String name() {
        return this.name;
    }
    public Address address() {
        return this.address;
    }
    public Phone phone() {
        return this.phone;
    }
    public Email email() {
        return this.email;
    }
    public Phone fax() {
        return this.fax;
    }
    public Website website() {
        return this.website;
    }
    public Double openingHour() {
        return this.openingHour;
    }
    public Double closingHour() {
        return this.closingHour;
    }
    public Integer maxVaccinesPerHour() {
        return this.maxVaccinesPerHour;
    }

    private Facility(final Facility.Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.address = builder.address;
        this.phone = builder.phone;
        this.email = builder.email;
        this.fax = builder.fax;
        this.website = builder.website;
        this.openingHour = builder.openingHour;
        this.closingHour = builder.closingHour;
        this.maxVaccinesPerHour = builder.maxVaccinesPerHour;
    }

    public static class Builder {
        private Integer id;
        private String name;
        private Address address;
        private Phone phone;
        private Email email;
        private Phone fax;
        private Website website;
        private Double openingHour;
        private Double closingHour;
        private int maxVaccinesPerHour;

        public Facility.Builder withId(final Integer id) {
            this.id = id;
            return this;
        }
        public Facility.Builder withName(final String name) {
            this.name = name;
            return this;
        }
        public Facility.Builder withAddress(final Address address) {
            this.address = address;
            return this;
        }
        public Facility.Builder withPhone(final Phone phone) {
            this.phone = phone;
            return this;
        }
        public Facility.Builder withEmail(final Email email) {
            this.email = email;
            return this;
        }
        public Facility.Builder withFax(final Phone fax) {
            this.fax = fax;
            return this;
        }
        public Facility.Builder withWebsite(final Website website) {
            this.website = website;
            return this;
        }
        public Facility.Builder withOpeningHour(final Double openingHour) {
            this.openingHour = openingHour;
            return this;
        }
        public Facility.Builder withClosingingHour(final Double closingHour) {
            this.closingHour = closingHour;
            return this;
        }
        public Facility.Builder withMaxVaccinesPerHour(final Integer maxVaccinesPerHour) {
            this.maxVaccinesPerHour = maxVaccinesPerHour;
            return this;
        }

        public Facility build() {
            return new Facility(this);
        }
    }

    @Override
    public FacilityDTO toDTO() {
        FacilityDTO.Builder builder = new FacilityDTO.Builder();
        builder.withId(id());
        builder.withName(name());
        if (address() != null) {
            builder.withAddressDTO(address().toDTO());
        } else {
            builder.withAddressDTO(null);
        }
        if (phone() != null) {
            builder.withPhoneDTO(phone().toDTO());
        } else {
            builder.withPhoneDTO(null);
        }
        if (email() != null) {
            builder.withEmailDTO(email().toDTO());
        } else {
            builder.withEmailDTO(null);
        }
        if (fax() != null) {
            builder.withFaxDTO(fax().toDTO());
        } else {
            builder.withFaxDTO(null);
        }
        if (website() != null) {
            builder.withWebsiteDTO(website().toDTO());
        } else {
            builder.withWebsiteDTO(null);
        }
        builder.withOpeningHour(openingHour());
        builder.withClosingingHour(closingHour());
        builder.withMaxVaccinesPerHour(maxVaccinesPerHour());
        return builder.build();
    }

    //JPA
    protected Facility() {}
}
