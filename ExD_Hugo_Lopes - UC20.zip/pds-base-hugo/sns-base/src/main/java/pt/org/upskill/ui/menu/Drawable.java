package pt.org.upskill.ui.menu;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

public interface Drawable {
    void draw(Menu menu);
}
