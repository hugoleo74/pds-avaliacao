package pt.org.upskill.ui;

public class ScheduleVaccinationOnBehalfOfUserUI extends UI {
}
