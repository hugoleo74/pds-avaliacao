package pt.org.upskill.db;

import pt.org.upskill.auth.User;
import pt.org.upskill.repository.JdbcRepository;
import pt.org.upskill.repository.UserRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserDB extends JdbcRepository implements PersistableObjectJdbc<User, String, String> {

    @Override
    public boolean save(Connection connection, User object) {
        String sqlCmd;
        sqlCmd = "select * from AppUser where code = ?";
        try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
            ps.setString(1, object.code());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    sqlCmd = "update AppUser set email = ?, password = ?, role = ? where code = ?";
                }
                else {
                    sqlCmd = "insert into AppUser(email, password, role, code) values (?, ?, ?, ?)";
                }
                //
                try (PreparedStatement ps2 = connection.prepareStatement(sqlCmd)) {
                    ps2.setString(1, object.email().address());
                    ps2.setString(2, object.password().value());
                    ps2.setString(3, object.role().name());
                    ps2.setString(4, object.code());
                    ps2.executeUpdate();
                    return true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return true;
        }
    }

    @Override
    public boolean delete(Connection connection, User object) {
        try {
            String sqlCmd;
            sqlCmd = "delete from AppUser where code = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setString(1, object.code());
                ps.executeUpdate();
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    @Override
    public User getById(Connection connection, String id) {
        try {
            String sqlCmd;
            sqlCmd = "select * from AppUser where code = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setString(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new UserRepository().buildFromResultSet(rs);
                }
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public User getByBusinessId(Connection connection, String businessId) {
        try {
            String sqlCmd;
            sqlCmd = "select * from AppUser where email = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setString(1, businessId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new UserRepository().buildFromResultSet(rs);
                }
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
