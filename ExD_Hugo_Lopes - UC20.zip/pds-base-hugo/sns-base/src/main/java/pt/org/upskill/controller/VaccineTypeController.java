package pt.org.upskill.controller;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.domain.VaccineType;

import pt.org.upskill.dto.DTO;
import pt.org.upskill.dto.KeyValueDTO;
import pt.org.upskill.jpa.JpaRepository;
import pt.org.upskill.repository.VaccineTypeRepository;

import javax.persistence.EntityManager;
import java.util.List;

public class VaccineTypeController implements UIable {
    VaccineTypeRepository vaccineTypeRepository = new VaccineTypeRepository();

    private VaccineType vaccineType;

    @Override
    public void register(DTO dto) {
        vaccineType = vaccineTypeRepository.createVaccineType(dto);
    }

    @Override
    public boolean save() {
        /*
        try {
            vaccineTypeRepository.beginTransaction();
            vaccineTypeRepository.save(vaccineType);
            vaccineTypeRepository.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            vaccineTypeRepository.rollback();
            return false;
        }
         */
        EntityManager em = JpaRepository.entityManager();
        try {
            em.getTransaction().begin();
            em.persist(vaccineType);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
            return false;
        }
    }

    @Override
    public List<KeyValueDTO> keyValueDTOList() { return vaccineTypeRepository.keyValueDTOList(); }
}
