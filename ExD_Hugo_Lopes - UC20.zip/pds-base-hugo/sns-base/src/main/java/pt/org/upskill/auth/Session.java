package pt.org.upskill.auth;

import pt.org.upskill.domain.Facility;

import java.util.Date;

public class Session {
    private Date logIn;
    private Date logOut;
    private Facility facility;
}
