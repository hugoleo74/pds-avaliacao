package pt.org.upskill.repository;

import pt.org.upskill.domain.Facility;
import pt.org.upskill.dto.FacilityDTO;
import pt.org.upskill.dto.KeyValueDTO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

public interface PersistableRepo<P, TId, TBId> {
    boolean save(P object);

    boolean delete(P object);

    P getById(TId id);

    P getByBusinessId(TBId businessId);

    List<P> getAll();

    P buildFromResultSet(ResultSet resultSet);

}
//public interface PersistableRepo {
//    boolean save(Object object) throws SQLException;
//    boolean delete(Object object) throws SQLException;
//}