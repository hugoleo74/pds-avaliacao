package pt.org.upskill.domain;

import pt.org.upskill.dto.DTOable;
import pt.org.upskill.dto.UserSNSDTO;


import javax.persistence.*;
import java.sql.Date;

@Entity
public class UserSNS implements DTOable<UserSNSDTO> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String birthDate;
    private String sex;
    private String postalAddress;
    private Integer phoneNumber;
    private String emailAddress;
    private String citizenCardNumber;
    private Integer userSNSNumber;

    public UserSNS(Integer id, String name, String birthDate, String sex, String postalAddress, Integer phoneNumber, String emailAddress, String citizenCardNumber, Integer userSNSNumber) {
        this.id = id;
        this.name = name;
        this.birthDate = birthDate;
        this.sex = sex;
        this.postalAddress = postalAddress;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.citizenCardNumber = citizenCardNumber;
        this.userSNSNumber = userSNSNumber;
    }

    public Integer id() {
        return id;
    }

    public String name() {
        return name;
    }

    public String birthDate() {
        return birthDate;
    }

    public String sex() {
        return sex;
    }

    public String postalAddress() {
        return postalAddress;
    }

    public Integer phoneNumber() {
        return phoneNumber;
    }

    public String emailAddress() {
        return emailAddress;
    }

    public String citizenCardNumber() {
        return citizenCardNumber;
    }

    public Integer userSNSNumber() {
        return userSNSNumber;
    }


    @Override
    public UserSNSDTO toDTO() {
        UserSNSDTO dto = new UserSNSDTO.Builder()
                .withId(id())
                .withName(name())
                .withDate(birthDate())
                .withSex(sex())
                .withPostalAddress(postalAddress())
                .withPhoneNumber(phoneNumber())
                .withEmailAddress(emailAddress())
                .withCitizenCardNumber(citizenCardNumber())
                .withUserSNSNumber(userSNSNumber())

                .build();
        return dto;
    }

    //Jpa
    protected UserSNS() {
    }
}