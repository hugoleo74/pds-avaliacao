package pt.org.upskill.controller;

import pt.org.upskill.domain.UserSNS;
import pt.org.upskill.dto.DTO;
import pt.org.upskill.dto.KeyValueDTO;
import pt.org.upskill.jpa.JpaRepository;
import pt.org.upskill.repository.Repositories;
import pt.org.upskill.repository.UserSNSRepository;

import javax.persistence.EntityManager;
import java.util.List;


public class UserSNSController implements UIable {
    UserSNSRepository userSNSRepository = new UserSNSRepository();
    private UserSNS userSNS;


    public void register(DTO dto) {
        userSNS = userSNSRepository.createUserSNS(dto);
    }


    public boolean save() {

//    public List<UserSNS> userSNSList() {
//        return userSNSRepository.userSNSList();
//    }

        EntityManager em = JpaRepository.entityManager();
        try {
            em.getTransaction().begin();
            em.persist(userSNS);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
            return false;
        }
    }
    public List<KeyValueDTO> keyValueDTOList() { return userSNSRepository.keyValueDTOList(); }
}





