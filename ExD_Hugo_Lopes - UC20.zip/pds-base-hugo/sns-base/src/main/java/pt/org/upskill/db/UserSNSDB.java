package pt.org.upskill.db;

import pt.org.upskill.domain.UserSNS;
import pt.org.upskill.repository.UserSNSRepository;
//import pt.org.upskill.domain.VaccineTech;
//import pt.org.upskill.repository.VaccineTechRepository;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserSNSDB implements PersistableObjectJdbc<UserSNS, Integer, String> {
    @Override
    public boolean save(Connection connection, UserSNS object) {
        String sqlCmd;
        sqlCmd = "select * from UserSNS where id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
            if (object.id() == null) {
                ps.setNull(1, Types.INTEGER);
            } else {
                ps.setInt(1, object.id());
            }
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    sqlCmd = "update UserSNS set name = ?, description = ? where id = ?";
                    try (PreparedStatement ps2 = connection.prepareStatement(sqlCmd)) {
                        ps2.setString(1, object.name());
                        ps2.setString(2, object.sex());
                        ps2.setInt(3, object.id());
                        ps2.executeUpdate();
                        return true;
                    }
                }
                else {
                    sqlCmd = "insert into UserSNS(name, description) values (?, ?)";
                    try (PreparedStatement ps2 = connection.prepareStatement(sqlCmd)) {
                        ps2.setString(1, object.name());
                        ps2.setString(2, object.sex());
                        ps2.executeUpdate();
                        return true;
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    @Override
    public boolean delete(Connection connection, UserSNS object) {
        try {
            String sqlCmd;
            sqlCmd = "delete from UserSNS where id = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setInt(1, object.id());
                ps.executeUpdate();
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    @Override
    public UserSNS getById(Connection connection, Integer id) {
        try {
            String sqlCmd;
            sqlCmd = "select * from UserSNS where id = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new UserSNSRepository().buildFromResultSet(rs);
                }
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public UserSNS getByBusinessId(Connection connection, String businessId) {
        try {
            String sqlCmd;
            sqlCmd = "select * from UserSNS where name = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setString(1, businessId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new UserSNSRepository().buildFromResultSet(rs);
                }
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
