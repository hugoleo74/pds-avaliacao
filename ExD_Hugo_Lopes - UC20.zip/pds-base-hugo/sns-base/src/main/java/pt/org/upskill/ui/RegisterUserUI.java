package pt.org.upskill.ui;

public class RegisterUserUI extends UI {
}
