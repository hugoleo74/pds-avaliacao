package pt.org.upskill.ui;

public class RegisterUserArrivalUI extends UI {
}
