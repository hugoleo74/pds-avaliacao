package pt.org.upskill.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaRepository {
    private static EntityManagerFactory factory = Persistence.createEntityManagerFactory("oracle-upskill");
    public static EntityManager entityManager() {return factory.createEntityManager();}
}
