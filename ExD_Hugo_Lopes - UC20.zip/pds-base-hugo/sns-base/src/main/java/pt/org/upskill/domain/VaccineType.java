package pt.org.upskill.domain;

import pt.org.upskill.dto.VaccineTypeDTO;
import pt.org.upskill.dto.DTOable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class VaccineType implements DTOable<VaccineTypeDTO> {
    @Id
    private String code;
    private String shortDescription;
    @ManyToOne
    private VaccineTech vaccineTech;

    public VaccineType(String code, String shortDescription, VaccineTech vaccineTech) {
        this.code = code;
        this.shortDescription = shortDescription;
        this.vaccineTech = vaccineTech;
    }

    public String code() {
        return code;
    }
    public String shortDescription() {
        return shortDescription;
    }
    public VaccineTech vaccineTech() {
        return vaccineTech;
    }

    @Override
    public VaccineTypeDTO toDTO() {
        VaccineTypeDTO.Builder builder = new VaccineTypeDTO.Builder();
        builder.withCode(code());
        builder.withShortDescription(shortDescription());
        if (vaccineTech() != null) {
            builder.withVaccineTechDTO(vaccineTech().toDTO());
        } else {
            builder.withVaccineTechDTO(null);
        }
        return builder.build();
    }

    //Jpa
    protected VaccineType() {}
}
