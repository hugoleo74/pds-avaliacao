package pt.org.upskill.repository;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.auth.Email;
import pt.org.upskill.auth.Password;
import pt.org.upskill.auth.User;
import pt.org.upskill.db.UserDB;
import pt.org.upskill.domain.Role;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserRepository extends JdbcRepository implements PersistableRepo<User, String, String> {

    @Override
    public boolean save(User object) {
        try {
            UserDB userDB = new UserDB();
            userDB.save(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean delete(User object) {
        try {
            UserDB userDB = new UserDB();
            userDB.delete(conn, object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public User getById(String id) {
        return new UserDB().getById(conn, id);
    }

    @Override
    public User getByBusinessId(String businessId) {
        return new UserDB().getByBusinessId(conn, businessId);
    }

    @Override
    public List<User> getAll() {
        try {
            List<User> list = new ArrayList<>();
            String sqlCmd = "select * from User";
            try (PreparedStatement ps = conn.prepareStatement(sqlCmd)) {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    list.add(buildFromResultSet(rs));
                }
                return list;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public User buildFromResultSet(ResultSet resultSet) {
        try {
            return new User(
                    resultSet.getString("code"),
                    new Role(resultSet.getString("role")),
                    new Email(resultSet.getString("email")),
                    new Password(resultSet.getString("password")));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
