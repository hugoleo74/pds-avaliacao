package pt.org.upskill.db;

import pt.org.upskill.domain.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RoleDB implements PersistableObjectJdbc<Role, String, String> {
    @Override
    public boolean save(Connection connection, Role object) {
        String sqlCmd;
        sqlCmd = "select * from Role where name = ?";
        try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
            ps.setString(1, object.name());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    sqlCmd = "update Role set name = name where name = ?";
                }
                else {
                    sqlCmd = "insert into Role(name) values (?)";
                }
                //
                try (PreparedStatement ps2 = connection.prepareStatement(sqlCmd)) {
                    ps2.setString(1, object.name());
                    ps2.executeUpdate();
                    return true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return true;
        }
    }

    @Override
    public boolean delete(Connection connection, Role object) {
        try {
            String sqlCmd;
            sqlCmd = "delete from Role where name = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setString(1, object.name());
                ps.executeUpdate();
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    @Override
    public Role getById(Connection connection, String id) {
        try {
            String sqlCmd;
            sqlCmd = "select * from Role where name = ?";
            try (PreparedStatement ps = connection.prepareStatement(sqlCmd)) {
                ps.setString(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    Role role = null;
                    try {
                        role = new Role(rs.getString("name"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return role;
                }
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FacilityDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Role getByBusinessId(Connection connection, String businessId) {
        return getById(connection, businessId);
    }
}
