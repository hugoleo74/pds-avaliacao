package pt.org.upskill.ui;
/**
 * @author Nuno Castro anc@isep.ipp.pt
 */

import pt.org.upskill.controller.UserSNSController;
import pt.org.upskill.controller.VaccineTechController;
import pt.org.upskill.dto.UserSNSDTO;
import pt.org.upskill.dto.VaccineTechDTO;


import static pt.org.upskill.ui.utils.Utils.readLineFromConsole;

public class RegisterUserSNSUI extends UI {
    private final UserSNSController userSNSController = new UserSNSController();

    public void run() {
        System.out.println("");
        System.out.println("CREATE USER SNS");
        System.out.println("-----------");

        try {
            //System asks: name, description
            String name = readLineFromConsole("User SNS Name: ");
            String birthDate = readLineFromConsole("User SNS Birthdate:");
            String sex = readLineFromConsole("User SNS Sex: ");
            String postalAddress = readLineFromConsole("SNS User post adress: ");
            int phoneNumber = Integer.parseInt(readLineFromConsole("SNS User phone number: "));
            String emailAddress = readLineFromConsole("SNS User email address: ");
            String citizenCardNumber = (readLineFromConsole("SNS User citizen card number: "));
            int userSNSNumber = Integer.parseInt(readLineFromConsole("SNS User number: "));

            //DTO creation
            UserSNSDTO dto = new UserSNSDTO.Builder()
                    .withName(name)
                    .withDate(birthDate)
                    .withSex(sex)
                    .withPostalAddress(postalAddress)
                    .withPhoneNumber(phoneNumber)
                    .withEmailAddress(emailAddress)
                    .withCitizenCardNumber(citizenCardNumber)
                    .withUserSNSNumber(userSNSNumber)
                    .build();

            //Registration
            userSNSController.register(dto);

            //Confirmation
            userSNSController.save();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
