package pt.org.upskill.db;

import java.sql.Connection;

public interface PersistableObjectJdbc<P, TId, TBid> {
    boolean save(Connection connection, P object);
    boolean delete(Connection connection, P object);
    P getById(Connection connection, TId id);
    P getByBusinessId(Connection connection, TBid businessId);
}
