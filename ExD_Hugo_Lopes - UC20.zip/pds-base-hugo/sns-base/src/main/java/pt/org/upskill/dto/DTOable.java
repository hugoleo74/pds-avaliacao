package pt.org.upskill.dto;

public interface DTOable<T> {
    T toDTO();
}
