package pt.org.upskill.dto;

import java.time.LocalTime;

public class FacilityDTO implements DTO {
    private Integer id;
    private String name;
    private AddressDTO addressDTO;
    private PhoneDTO phoneDTO;
    private EmailDTO emailDTO;
    private PhoneDTO faxDTO;
    private WebsiteDTO websiteDTO;
    private Double openingHour;
    private Double closingHour;
    private int maxVaccinesPerHour;

    public Integer id() {
        return this.id;
    }

    public String name() {
        return this.name;
    }

    public AddressDTO addressDTO() {
        return this.addressDTO;
    }

    public PhoneDTO phoneDTO() {
        return this.phoneDTO;
    }

    public EmailDTO emailDTO() {
        return this.emailDTO;
    }

    public PhoneDTO faxDTO() {
        return this.faxDTO;
    }

    public WebsiteDTO websiteDTO() {
        return this.websiteDTO;
    }

    public Double openingHour() {
        return this.openingHour;
    }

    public Double closingHour() {
        return this.closingHour;
    }

    public Integer maxVaccinesPerHour() {
        return this.maxVaccinesPerHour;
    }

    private FacilityDTO(final FacilityDTO.Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.addressDTO = builder.addressDTO;
        this.phoneDTO = builder.phoneDTO;
        this.emailDTO = builder.emailDTO;
        this.faxDTO = builder.faxDTO;
        this.websiteDTO = builder.websiteDTO;
        this.openingHour = builder.openingHour;
        this.closingHour = builder.closingHour;
        this.maxVaccinesPerHour = builder.maxVaccinesPerHour;
    }

    public static class Builder {
        private Integer id;
        private String name;
        private AddressDTO addressDTO;
        private PhoneDTO phoneDTO;
        private EmailDTO emailDTO;
        private PhoneDTO faxDTO;
        private WebsiteDTO websiteDTO;
        private Double openingHour;
        private Double closingHour;
        private int maxVaccinesPerHour;

        public FacilityDTO.Builder withId(final Integer id) {
            this.id = id;
            return this;
        }
        public FacilityDTO.Builder withName(final String name) {
            this.name = name;
            return this;
        }
        public FacilityDTO.Builder withAddressDTO(final AddressDTO addressDTO) {
            this.addressDTO = addressDTO;
            return this;
        }
        public FacilityDTO.Builder withPhoneDTO(final PhoneDTO phoneDTO) {
            this.phoneDTO = phoneDTO;
            return this;
        }
        public FacilityDTO.Builder withEmailDTO(final EmailDTO emailDTO) {
            this.emailDTO = emailDTO;
            return this;
        }
        public FacilityDTO.Builder withFaxDTO(final PhoneDTO faxDTO) {
            this.faxDTO = faxDTO;
            return this;
        }
        public FacilityDTO.Builder withWebsiteDTO(final WebsiteDTO websiteDTO) {
            this.websiteDTO = websiteDTO;
            return this;
        }
        public FacilityDTO.Builder withOpeningHour(final Double openingHour) {
            this.openingHour = openingHour;
            return this;
        }
        public FacilityDTO.Builder withClosingingHour(final Double closingHour) {
            this.closingHour = closingHour;
            return this;
        }
        public FacilityDTO.Builder withMaxVaccinesPerHour(final Integer maxVaccinesPerHour) {
            this.maxVaccinesPerHour = maxVaccinesPerHour;
            return this;
        }

        public FacilityDTO build() {
            return new FacilityDTO(this);
        }
    }
}