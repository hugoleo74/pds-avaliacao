package pt.org.upskill.ui;

public class ScheduleVaccinationUI extends UI {
}
